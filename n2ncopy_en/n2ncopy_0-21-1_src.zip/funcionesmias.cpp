#include "cabecera.h"

void renombrarsiexistearchivo(MiPathStr * ruta);


////////////////////////////////////////////////////////////////////

void MostrarError(TCHAR *ficheroerror, INT lineaerror)
{
	MiMostrarError(ficheroerror, lineaerror);
/*    TCHAR cadena1[MIMAXPATH];
    #ifdef CASTELLANO
        _stprintf(cadena1, TEXT("Ha ocurrido un error grave en la l�nea:\r\n%d\r\nDel fichero:\r\n%s\r\nLa aplicaci�n va a finalizar"), lineaerror, ficheroerror);
    #else
        _stprintf(cadena1, TEXT("An error has hapened in the line:\r\n%d\r\nOf file:\r\n%s\r\nThe program will finish"), lineaerror, ficheroerror);
    #endif
    MessageBox(NULL, cadena1, TEXT(SZTITULO), MB_OK | MB_ICONERROR);
*/
    exit(1);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HANDLE CreateFileHechaPorMi(WCHAR * lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes,
                            DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile)
{
	HANDLE r;
	TCHAR nombrelargo[MIMAXPATH];
	//DWORD acceso;
//	if(lpFileName[0] == L'\\')
//		nombrelargo[0] = L'\0';
//	else
		//_tcscpy(nombrelargo, TEXT("\\\\?\\"));
	Miwcscpypref(nombrelargo, lpFileName);
	if(dwDesiredAccess != GENERIC_READ)
	{
		if(GetFileAttributes(nombrelargo) != INVALID_FILE_ATTRIBUTES)
		{
			if(GetFileAttributes(nombrelargo) & FILE_ATTRIBUTE_DIRECTORY)
			{
				MiPathStr mps;
				Miwcscpy(mps, lpFileName);
				renombrarsiexistearchivo(&mps);
//				if(lpFileName[0] == L'\\')
//					nombrelargo[0] = L'\0';
//				else
				//	_tcscpy(nombrelargo, TEXT("\\\\?\\"));

				//_tcscpy(nombrelargo, TEXT("\\\\?\\"));
				Miwcscpypref(nombrelargo, lpFileName);
			}
			else
			{
				SetFileAttributes(nombrelargo, FILE_ATTRIBUTE_NORMAL);
				DeleteFile(nombrelargo);
			}
		}
	}
	
//	MessageBox(NULL, nombrelargo, lpFileName, MB_OK);
	r = CreateFile(nombrelargo, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition,
                      dwFlagsAndAttributes, hTemplateFile);
	if((r == INVALID_HANDLE_VALUE) && (GetLastError() == 5))
	{
		WCHAR st[MIMAXPATH * 2];
		swprintf(st, MIMAXPATH * 2, SZACCDENLARGO, MiSinPref(nombrelargo));
		MessageBox(NULL, st, SZACCDENCORTO, MB_OK | MB_ICONERROR);
		ExitProcess(0);
	}
	return r;
}
////////////////////////////////////////////////////////////////////////////////
DWORD GetFileAttributesHechaPorMi(WCHAR * lpFileName)
{
  TCHAR nombrelargo[MIMAXPATH];
  //_tcscpy(nombrelargo, TEXT("\\\\?\\"));
  Miwcscpypref(nombrelargo, lpFileName);
  return (GetFileAttributes(nombrelargo));
}
///////////////////////////////////////////////////////////////////////
BOOL PathFileExistsHechaPorMi(WCHAR * pszPath)
{
  TCHAR nombrelargo[MIMAXPATH];
  //_tcscpy(nombrelargo, TEXT("\\\\?\\"));
  Miwcscpypref(nombrelargo, pszPath);
  return (PathFileExists(nombrelargo));
}
//////////////////////////////////////////////////////////////////////
BOOL CreateDirectoryHechaPorMi(WCHAR * lpPathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes)
{
	TCHAR nombrelargo[MIMAXPATH];
	DWORD atributos;
	//_tcscpy(nombrelargo, TEXT("\\\\?\\"));
	Miwcscpypref(nombrelargo, lpPathName);
	atributos = GetFileAttributes(nombrelargo);
	if(atributos != INVALID_FILE_ATTRIBUTES)
	{
		if(atributos & FILE_ATTRIBUTE_DIRECTORY)
			return TRUE;
	}
	return (CreateDirectory(nombrelargo, lpSecurityAttributes));
}
//////////////////////////////////////////////////////////////////////
HANDLE FindFirstFileExHechaPorMi(WCHAR * lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData,
                       FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags)
{
  TCHAR nombrelargo[MIMAXPATH];
  //_tcscpy(nombrelargo, TEXT("\\\\?\\"));
  Miwcscpypref(nombrelargo, lpFileName);
  return (FindFirstFileEx(nombrelargo, fInfoLevelId, lpFindFileData, fSearchOp, lpSearchFilter, dwAdditionalFlags));
}
/////////////////////////////////////////////////////////////////
void PathStripPathHechaPorMi(LPTSTR pszPath)
{
  TCHAR nombrelargo[MIMAXPATH];
  //_tcscpy(nombrelargo, TEXT("\\\\?\\"));
  Miwcscpypref(nombrelargo, pszPath);
  PathStripPath(nombrelargo);
  _tcscpy(pszPath, nombrelargo);
}
////////////////////////////////////////////////////
LPTSTR PathAddBackslashHechaPorMi(LPTSTR lpszPath)
{
  if(lpszPath[_tcslen(lpszPath) - 1] != TEXT('\\'))
  _tcscat(lpszPath, TEXT("\\"));
  return lpszPath;
}
