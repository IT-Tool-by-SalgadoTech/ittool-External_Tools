#ifndef CABECERA_H_INCLUDED
#define CABECERA_H_INCLUDED

#define NUMEROVERSION 0,21,1,0
#define TEXTOVERSION L"0.21.1.0"

#define _CRT_SECURE_NO_DEPRECATE 1
#define _CRT_NON_CONFORMING_SWPRINTFS 1
#define CASTELLANO
//#define ENGLISH 
#include "..\..\..\MiLibreria\h\MiLibreria.h"
  

  
 
 

//#include "d:/Programando/MiLibreria/h/MiPathStr.h"




#define _WIN32_WINNT 0x0500


#include <tchar.h>
#include <wchar.h>
#include <windows.h>
#include <commctrl.h>
#include <string.h>
#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>

//#define MIMAXPATH 2600

HANDLE CreateFileHechaPorMi(WCHAR * lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes,
                            DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);
DWORD GetFileAttributesHechaPorMi(WCHAR * lpFileName);
BOOL PathFileExistsHechaPorMi(WCHAR * pszPath);
HANDLE FindFirstFileExHechaPorMi(WCHAR * lpFileName, FINDEX_INFO_LEVELS fInfoLevelId, LPVOID lpFindFileData,
                       FINDEX_SEARCH_OPS fSearchOp, LPVOID lpSearchFilter, DWORD dwAdditionalFlags);
BOOL CreateDirectoryHechaPorMi(WCHAR * lpPathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
void PathStripPathHechaPorMi(WCHAR * pszPath);
LPTSTR PathAddBackslashHechaPorMi(WCHAR * lpszPath);
void MostrarError(TCHAR *ficheroerror, INT lineaerror);
//WCHAR * Miwcscpypref(WCHAR * des, WCHAR * origen);

#define SALIR 0
#define SZTITULO "n2ncopy"

#ifdef CASTELLANO
    #define SZMOVING L"Moviendo:"
    #define SZDELETING L"Borrando:"
    #define SZERROR "Ha ocurrido un error y n2ncopy va a terminar."
    #define SZELMSCOPIAR "Elementos a copiar o mover"
    #define SZDESTINOSCOPY "Destinos a los que copiar o mover"
    #define SZQUITARSELEC "Quitar seleccionado"
    #define SZQUITARTODOS "Quitar todos"
    #define SZPFLEAESTO L"Por favor, lea esto:"
    #define SZCONTENIDOENSEGUNDO "Este elemento no se a�adir� porque est� contenido en el segundo:"
    #define SZESTACONTENIDOEN "\r\nEst� contenido en:\r\n"
    #define SZTAREATERMINADA "La tarea ha finalizado correctamente"
    #define SZTAREAINTERRUMPIDA "La tarea ha sido interrumpida por el usuario"
    #define SZCANCELAR "Cancelar"
    #define SZSINOMBRESIGUALES "Si los nombres son id�nticos"
    #define SZSOBRESCRIBIR "Sobrescribir"
    #define SZNOADDESTAENLISTA "Este elemento no se a�adir� porque ya est� en la lista:"
    #define SZCONTIENEA "\r\nContiene a:\r\n"
    #define SZRENOMBRARAUTO "Renombrar autom�ticamente"
    #define SZPROGOPERACION "Progreso de la operaci�n:"
    #define SZNOCANESCRIBIR "Este elemento no se a�adir� porque no puedo escribir en �l:"
    #define SZNODIRECTORIO "Este elemento no se a�adir� porque no es un directorio:"
    #define SZPRIMCONTSEG "Este primer elemento no se a�adir� porque contiene al segundo:"
    #define SZDISKDRIVE "Este elemento no se a�adir� porque es una unidad de disco:"
    #define SZNOITEMTOWORK "No hay ning�n elemento que copiar o mover."
    #define SZNOTARGET "No hay ning�n destino al que copiar o mover."
    #define SZCOPIANDO L"Copiando:"
    #define SZQUIT "Salir de la aplicaci�n"
    #define SZTIPOTAREA "Tipo de tarea a realizar"
    #define SZDOTASK "Realizar la tarea"
    #define SZRETURN "Volver..."
    #define SZCOPY L"Copiar"
    #define SZMOVE L"Mover"
    //#define SZCOPIARCONEXTENSIONES "A�adir s�lo los ficheros con estas extensiones (separadas por comas):"
    //#define SZCOPIARSOLOARCHIVOS "A�adir s�lo ficheros"
    //#define SZADDFILESSUBDIRS "A�adir los ficheros incluidos en los subdirectorios"
    //#define SZFILES "Ficheros"
    #define SZBORRARLISTAS L"Borrar listas"
    #define SZBORRARLISTADOS "Borrar las listas si la operaci�n acaba con �xito"
    #define SZNOEXITO "No mostrar un di�logo cuando acaba la tarea si hay �xito"
    #define SZANIADIRCARPETADESTINO "A�adir carpeta de destino"
    #define SZANIADIRCONTENIDOCARPETAORIGEN "A�adir contenido de carpeta para copiar o mover"
    #define SZANIADIRORIGENES "A�adir ficheros para copiar o mover"
    #define SZANIADIRCARPETAORIGEN "A�adir carpeta para copiar o mover"
	#define SZBORRARCONTENIDOS "Borrar por completo el contenido de las carpetas de destino antes de la copia"
	#define SZASKBORRARCONTENIDOS "Todos los contenidos de todas las carpetas de destino ser�n borrados definitivamente antes de la copia.\r\nEst� usted completamente seguro?"
	#define SZELEMSCONTENTCOPYORMOVE "Elementos cuyo contenido se copiar� o mover�:"
	#define SZABOUT L"Acerca de..."
#define SZNOHABORRADO1 L"El elemento:\r\n\r\n"
#define SZNOHABORRADO2 L"\r\nNo se ha podido borrar.\r\n"
#define SZNOHABORRADO3 L"�Desea continuar con la ejecuci�n del programa e ignorar los errores como �ste?"
#define SZACCDENLARGO L"Se ha denegado el acceso al fichero:\r\n\r\n%s\r\n\r\nCompruebe que tiene permisos para acceder a �l.\r\n\r\nLa aplicaci�n se va a cerrar."
#define SZACCDENCORTO L"El sistema ha denegado el acceso al fichero:"
#define SZNOHACERNADA L"No hacer nada"


#endif
#ifdef ENGLISH 
    #define SZMOVING L"Moving:"
    #define SZDELETING L"Erasing:"
    #define SZERROR "An error has happened and n2ncopy will terminate."
    #define SZPFLEAESTO L"Please, read this:"
    #define SZQUITARTODOS "Remove all"
    #define SZQUITARSELEC "Remove selected"
    #define SZELMSCOPIAR "Elements to copy or to move"
    #define SZDESTINOSCOPY "Targets to which to copy or to move"
    #define SZCONTENIDOENSEGUNDO "This element will not be added because it is contained in the second one:"
    #define SZESTACONTENIDOEN "\r\nIs contained in:\r\n"
    #define SZTAREATERMINADA "The task has finished succesfully"
    #define SZTAREAINTERRUMPIDA "The task has been interrupted by the user"
    #define SZCANCELAR "Cancel"
    #define SZSINOMBRESIGUALES "If names are identical"
    #define SZSOBRESCRIBIR "Overwrite"
    #define SZNOADDESTAENLISTA "This item will not be added because it is already in the list"
    #define SZCONTIENEA "\r\nContains to:\r\n"
    #define SZRENOMBRARAUTO "Rename automaticaly"
    #define SZPROGOPERACION "Task progress"
    #define SZNOCANESCRIBIR "This item will not be added because I can not write into it:"
    #define SZNODIRECTORIO "This item will not be added because it is not a folder:"
    #define SZPRIMCONTSEG "This first item will not be added because it contains the second one:"
    #define SZDISKDRIVE "This item will not be added because it is a disk drive:"
    #define SZNOITEMTOWORK "There is no item to copy or to move."
    #define SZNOTARGET "There is no target to which to copy or to move."
    #define SZCOPIANDO L"Copying:"
    #define SZQUIT "Quit the program"
    #define SZTIPOTAREA "Kind of task to do"
    #define SZDOTASK "Do the task"
    #define SZRETURN "Return..."
    #define SZCOPY L"Copy"
    #define SZMOVE L"Move"
    //#define SZCOPIARCONEXTENSIONES "Add only of files with these extensions (comma separated):"
    //#define SZCOPIARSOLOARCHIVOS "Add only files"
    //#define SZADDFILESSUBDIRS "Add the files contained into the subfolders"
    //#define SZFILES "Files"
    #define SZBORRARLISTAS L"Erase lists"
    #define SZBORRARLISTADOS "Erase lists if task ends succesfully"
    #define SZNOEXITO "Do not show a dialog when task ends if ends succesfully"
    #define SZANIADIRCARPETADESTINO "Add target folder"
    #define SZANIADIRCONTENIDOCARPETAORIGEN "Add a folder content to copy or to move"
    #define SZANIADIRORIGENES "Add files to copy or to move"
    #define SZANIADIRCARPETAORIGEN "Add folder to copy or to move"
	#define SZBORRARCONTENIDOS "Erase completely all target folders contents before the copy"
	#define SZASKBORRARCONTENIDOS "All the contents of all target folders will be erased completely before the copy.\r\nAre you absolutely sure?"
	#define SZELEMSCONTENTCOPYORMOVE "Items which content will be copied or moved:"
	#define SZABOUT L"About..."
#define SZNOHABORRADO1 L"The item:\r\n\r\n"
#define SZNOHABORRADO2 L"\r\nCan not be deleted.\r\n"
#define SZNOHABORRADO3 L"\r\nDo you want to continue with the program execution and ignore this kind of errors?"
#define SZACCDENLARGO L"Access has been denied to file:\r\n\r\n%s\r\n\r\nTest if you can access to it.\r\n\r\nThe program will close."
#define SZACCDENCORTO L"System has denied access to this file:"
#define SZNOHACERNADA L"Do nothing"

#endif


#define IDD_DIALOG1                             1000
#define IDLISTELEMSCOPIAR                               1002
#define IDQUITARSELECCIONADOSELEMENTOSCOPIAR                             1003
#define IDQUITARTODOSELEMENTOSCOPIAR /*IDC_BUTTON2*/                             1004
#define IDLISTADESTINOSCOPIAR /*IDC_LIST2*/                               1005
#define IDBQUITARSELECTEDDESTINOS /*IDC_BUTTON3*/                             1006
#define IDBQUITARTODOSDESTINOS /*IDC_BUTTON4*/                             1007
#define IDRESCRIBIR /*IDC_RADIO1*/                              1008
#define IDRENOMBRARAUTO /*IDC_RADIO2*/                              1009
#define IDBSALIRDELPROGRAMA /*IDC_BUTTON5*/                             1010
#define IDBVOLVERAVENTANITA /*IDC_BUTTON6*/                             1011
#define IDBDOTASK /*IDC_BUTTON7*/                             1012
#define IDCOPIAR /*IDC_RADIO3 */                              1013
#define IDMOVER /*IDC_RADIO4 */                              1014
#define IDC_STATIC1                             1015
#define IDC_STATIC2                             1016
#define ID_TEXTOACCION                             1017
#define ID_TEXTOELEMENTO                             1018
#define IDBOTONCANCELAR                             1019
#define IDD_DIALOG2                             1020
#define TEMPORIZADOR                            1021
#define IDC_CHECKBOX2                             1022
#define IDC_TEXT1                               1023
#define IDC_STATIC5                             1024
#define IDC_CHECKBOX1                       1025
#define IDC_CHECKBOX3                       1026
#define ICONOGRANDE                             1027
#define ICONOPEQUE                              1028
#define MENUSALIR                               1029
#define MENUANIADIRDESTINO                      1030
#define MENUANIADIRCONTENIDOORIGEN              1031
#define MENUANIADIRFICHEROSORIGENES             1032
#define MENUANIADIRDIRECTORIOORIGEN             1033
#define MENUCOPIAR                              1034
#define MENUMOVER                               1035
#define IDCHECKBOXERASECONTENTS					1036
#define IDLISTACONTENIDOSCOPIAR /*IDC_LIST3*/								1037
#define IDBQUITARSELECCIONADOSELEMENTOSCOPIARINTERIOR /*IDC_BUTTON9*/								1038
#define IDBQUITARTODOSELEMENTOSCOPIARINTERIOR							1039
#define IDBOTONCOPIAR                           1040
#define IDBOTONBORRAR                           1041
//#define IDLISTAARCHIVOS                         1042
//#define IDLISTADESTINOS                         1043
//#define IDLISTACARPETAS                         1044
#define MENUABOUT								1045
#define IDNOHACERNADA							1046
#define WM_MIDROPFILES			(WM_APP + 1)
#define WM_ACCION				(WM_APP + 2)

typedef TCHAR RUTAARCHIVO[MIMAXPATH];
typedef RUTAARCHIVO * PDOBLERUTAARCHIVO;

typedef struct copiadata
{
    MiListaPunteros *listaArchivos;
    MiListaPunteros *listadestinos;
	MiListaPunteros *listacarpetas;
    INT numdatos;
    INT numdestinos;
	INT numcarpetas;
    BOOL sobreescribir;
    BOOL mover;
	BOOL BorrarContenidoDestinos;
	BOOL nohacernada;
	BOOL renombrar;
} DATOSDECOPIA, * LPDATOSDECOPIA;

typedef struct subprocdata
{
    LPDATOSDECOPIA pdatoscopia;
    HANDLE evento;
    HWND ventana;
} SUBPROCDATA, * LPSUBPROCDATA;


#endif // CABECERA_H_INCLUDED

