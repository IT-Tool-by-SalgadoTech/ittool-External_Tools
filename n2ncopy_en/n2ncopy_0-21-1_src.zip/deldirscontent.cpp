#include "cabecera.h"


static HANDLE evento;

static LPSUBPROCDATA psd;
void suIndicar(WCHAR * accion, MiPathStr *item, HWND hw);

void renombrarsiexistedir(MiPathStr *dir);
void renombrarsiexistearchivo(MiPathStr *ruta);

void edindicar(WCHAR ruta[], HWND hventana);
void edindicarmover(WCHAR ruta[], HWND hventana);

void edmovefolder(WCHAR folder[], WCHAR target[], BOOL overwrite,
				  HWND hventana, BOOL nohacernada, BOOL *nosehacopiado);
/////////////////////////////////////////////////////////////////
void edBorrarContenidoDestinos(LPSUBPROCDATA lpspd)
//Borra el contenido de todas las carpetas de destino
//si asi lo ha indicado el usuario.
{
	INT x;
	psd = lpspd;
	if(lpspd->pdatoscopia->BorrarContenidoDestinos != TRUE)
		return;
	evento = lpspd->evento;
	for(x = 0; x < lpspd->pdatoscopia->numdestinos; x++)
	{
		edindicar((WCHAR *) *((MiPathStr *)lpspd->pdatoscopia->listadestinos->getPunteroAt(x)), lpspd->ventana);
		MiRemoveFolder((WCHAR *) *((MiPathStr *)lpspd->pdatoscopia->listadestinos->getPunteroAt(x)), FALSE);
		if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
            return;
	}
}
/////////////////////////////////////////////////////////////////////
void edindicar(WCHAR ruta[], HWND hventana)
{
	MiPathStr rut;
	Miwcscpy(rut, ruta);
	suIndicar(SZDELETING, &rut, hventana);
}
/////////////////////////////////////////////////////////
void edmovefile(WCHAR file[], WCHAR target[], BOOL overwrite,
				HWND hventana, BOOL nohacernada, BOOL *nosehacopiado)
{
	MiPathStr destino;
	MiPathStr origen;
	DWORD atr;
	INT x;
	x = MiEncontrarUltimaOcurrenciaCaracter(file, L'\\'); 
	Miwcscpypref(destino, target);
	MiPathAddBackSlash(destino);
	Miwcscat(destino, &file[x + 1]);
	if(GetFileAttributes(destino) != INVALID_FILE_ATTRIBUTES)
	{
		//Existe un elemento en el destino con el mismo nombre.
		MiPathStr rutaDestinoSinPref;
		Miwcscpy(rutaDestinoSinPref, MiSinPref(destino));
		if(overwrite == TRUE)
		{
			if(GetFileAttributes(destino) & FILE_ATTRIBUTE_DIRECTORY)
			{
				//Hay una carpeta en la carpeta destino que se llama igual
				//que el fichero de origen.
				renombrarsiexistearchivo(&rutaDestinoSinPref);
				Miwcscpypref(destino, rutaDestinoSinPref);
			}
			else
			{
				//Existe un fichero en el destino que se llama igual 
				//que el fichero de origen.
				//Como se sobrescribe, se borra el fichero del mismo nombre
				//que hay en el destino.
				edindicar(rutaDestinoSinPref, psd->ventana);
				MiDeleteFile(rutaDestinoSinPref);
			}
		}
		else if(nohacernada == TRUE)
        {
            *nosehacopiado = TRUE;
			return;
        }
		else
		{
			//Solo queda el modo renombrar.
			//Se renombra el fichero porque esta activado
			//el modo renombrar.
			renombrarsiexistearchivo(&rutaDestinoSinPref);
			Miwcscpypref(destino, rutaDestinoSinPref);
		}
	}
	Miwcscpypref(origen, file);
	edindicarmover(file, hventana);
	EJECUTARSIRETORNOIG(GetFileAttributes(origen), INVALID_FILE_ATTRIBUTES, atr);
	EJECUTARNORETORNOIG(MoveFile(origen, destino), 0);
	EJECUTARNORETORNOIG(SetFileAttributes(destino, atr), 0);
	EJECUTARNORETORNOIG(GetFileAttributes(destino), INVALID_FILE_ATTRIBUTES);
	//*nosehacopiado = FALSE;
}
///////////////////////////////////////////////////////////////
void edtrataritemmovefolder(WCHAR * fileName, DWORD atrs, MiPathStr rutaOrigen, WCHAR * target, BOOL overwrite,
				  HWND hventana, BOOL nohacernada, BOOL *nosehacopiado)
{
	MiPathStr origen, destino;
	if(wcscmp(fileName, L".") && wcscmp(fileName, L".."))
	{
		Miwcscpy(origen, MiSinPref(rutaOrigen));
		Miwcscat(origen, fileName);
		if(atrs & FILE_ATTRIBUTE_DIRECTORY)
		{
			Miwcscpy(destino, target);
			MiPathAddBackSlash(destino);
			Miwcscat(destino, fileName);
			edmovefolder(origen, destino,  overwrite, hventana, nohacernada, nosehacopiado);
		}
		else
		{
			edmovefile(origen, target, overwrite, hventana, nohacernada, nosehacopiado);
		}
	}
}
///////////////////////////////////////////////////////////////
void edmovefolder(TCHAR folder[], TCHAR target[], BOOL overwrite,
				  HWND hventana, BOOL nohacernada, BOOL *nosehacopiado)
{
	MiPathStr rutaOrigen;
	MiPathStr rutaOrigenSinAsterisco;
	MiPathStr rutaDestino;
	MiPathStr rutaRenombrada;
	HANDLE hmanejador;
	WIN32_FIND_DATA fd;	
	//Si la carpeta de destino existe, se renombra si es necesario.
	Miwcscpy(rutaRenombrada, target);
	if((overwrite == FALSE) && (nohacernada == FALSE))
		renombrarsiexistedir(&rutaRenombrada);
	Miwcscpypref(rutaDestino, rutaRenombrada);
	//Si la carpeta de destino existe y no se debe de sobrescribir
	//Se sale de la funcion
	if((nohacernada == TRUE) && (GetFileAttributes(rutaDestino) != INVALID_FILE_ATTRIBUTES))
    {
        *nosehacopiado = TRUE;
		return;
    }
	//Si la carpeta destino no existe, se mueve la carpeta de origen
	Miwcscpypref(rutaOrigen, folder);
	if(GetFileAttributes(rutaDestino) == INVALID_FILE_ATTRIBUTES)
    {
        edindicarmover(folder, hventana);
	    EJECUTARNORETORNOIG(MoveFile(rutaOrigen, rutaDestino), 0);
		//*nosehacopiado = FALSE;
        return;
    }
	//Preparo para listar el contenido de la carpeta
	MiPathAddBackSlash(rutaOrigen);
	Miwcscpy(rutaOrigenSinAsterisco, rutaOrigen);
	Miwcscat(rutaOrigen, TEXT("*"));
	//Listo el contenido de la carpeta
	EJECUTARSIRETORNOIG(FindFirstFileEx(rutaOrigen, FindExInfoStandard, &fd, 
										FindExSearchNameMatch, NULL, 0), 
										INVALID_HANDLE_VALUE, hmanejador);
	edtrataritemmovefolder(fd.cFileName, fd.dwFileAttributes, rutaOrigenSinAsterisco, target, overwrite,
							hventana, nohacernada, nosehacopiado);
	while(FindNextFile(hmanejador, &fd) != 0)
	{
		//Compruebo si el usuario ha cancelado
		if(WaitForSingleObject(evento, 0) == WAIT_OBJECT_0)
        {
			FindClose(hmanejador);
            return;
        }
		edtrataritemmovefolder(fd.cFileName, fd.dwFileAttributes, rutaOrigenSinAsterisco, target, overwrite,
							hventana, nohacernada, nosehacopiado);
	}
	EJECUTARNORETORNODI(GetLastError(), ERROR_NO_MORE_FILES);
	EJECUTARNORETORNOIG(FindClose(hmanejador), 0);
	//Elimino la carpeta de origen.
	edindicar(folder, psd->ventana);
	MiRemoveFolder(folder, TRUE);
	//*nosehacopiado = FALSE;
	return;
}
/////////////////////////////////////////////////////////////
void edmoverelemento(TCHAR elemento[], TCHAR target[], BOOL overwrite, 
					 HWND hventana, BOOL nohacernada, BOOL *nosehacopiado)
{
	MiPathStr ruta;
	INT x;
	Miwcscpypref(ruta, elemento);
	if(!(GetFileAttributes(ruta) & FILE_ATTRIBUTE_DIRECTORY))
		edmovefile(elemento, target, overwrite, hventana, nohacernada, nosehacopiado);
	else
	{
		for(x = (INT)  wcslen(elemento); x >= 0; x--)
		{
			if(elemento[x] == L'\\')
				break;
		}
		Miwcscpypref(ruta, target);
		MiPathAddBackSlash(ruta);
		wcscat(ruta, &elemento[x + 1]);
		edmovefolder(elemento, MiSinPref(ruta), overwrite, hventana, nohacernada, nosehacopiado);
	}
}
/////////////////////////////////////////////////
void edindicarmover(WCHAR ruta[], HWND hventana)
{
	MiPathStr rut;
	Miwcscpy(rut, ruta);
	suIndicar(SZMOVING, &rut, hventana);
}
//////////////////////////////////////////////
void edborrarelemento(WCHAR elemento[])
{
	MiPathStr ruta;
	Miwcscpypref(ruta, elemento);
	if(GetFileAttributes(ruta) == INVALID_FILE_ATTRIBUTES)
		return;
	if(GetFileAttributes(ruta) & FILE_ATTRIBUTE_DIRECTORY)
	{
		edindicar(elemento, psd->ventana);
		MiRemoveFolder(elemento, TRUE);
	}
	else
	{
		edindicar(elemento, psd->ventana);
		MiDeleteFile(elemento);
	}
}