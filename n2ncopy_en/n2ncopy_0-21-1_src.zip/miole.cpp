#include "cabecera.h"
#include "miole.h"

HRESULT __stdcall CIDropSource::QueryInterface(REFIID riid, void ** ppv)
{
    if (IsEqualIID(riid, IID_IDropSource) || IsEqualIID(riid, IID_IUnknown))
	{
        *ppv = reinterpret_cast<IDropSource*>(this);
		return S_OK;
	}
    else
	{
        *ppv = NULL;
		return E_NOINTERFACE;
	}
}
///////////////////////////////////////////////////////////////
ULONG __stdcall CIDropSource::AddRef(void)
{
    return (ULONG)InterlockedIncrement(&m_nRef);
}
//////////////////////////////////////////////////////
ULONG __stdcall CIDropSource::Release(void)
{
    LONG ret = InterlockedDecrement(&m_nRef);
    return ret;
}
//////////////////////////////////////////////////////
HRESULT __stdcall CIDropSource::QueryContinueDrag(BOOL fEscapePressed, DWORD grfKeyState)
{
    if(fEscapePressed)
        return DRAGDROP_S_CANCEL;
	else if(!(grfKeyState & MK_LBUTTON))
        return DRAGDROP_S_DROP;
    else
        return S_OK;
}
/////////////////////////////////////////////////////////
HRESULT __stdcall CIDropSource::GiveFeedback(DWORD dwEffect)
{
	PARNOUSADO(dwEffect);
    return DRAGDROP_S_USEDEFAULTCURSORS;
}
///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
HRESULT __stdcall CIDropTarget::DragEnter(IDataObject *pDataObject, DWORD grfKeyState, 
                                              POINTL pt, DWORD *pdwEffect)
{
    fAllowDrop = QueryDataObject(pDataObject);	
    if(fAllowDrop)
    {
        *pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
		SetFocus(hw);
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}
	return S_OK;
}
/////////////////////////////////////////////////////
bool CIDropTarget::QueryDataObject(IDataObject *pDataObject)
{
    FORMATETC fmtetc = {CF_HDROP, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
    return pDataObject->QueryGetData(&fmtetc) == S_OK ? true : false;
}
////////////////////////////////////////////////////////
DWORD CIDropTarget::DropEffect(DWORD grfKeyState, POINTL pt, DWORD dwAllowed)
{
	DWORD dwEffect;
	dwEffect = dwAllowed & DROPEFFECT_COPY;
	PARNOUSADO(pt);
	PARNOUSADO(grfKeyState);
	return dwEffect;
}
///////////////////////////////////////////////////////////
HRESULT __stdcall CIDropTarget::DragOver(DWORD grfKeyState, POINTL pt, DWORD * pdwEffect)
{
	RECT rect;
	POINT point;
	point.x = pt.x;
	point.y = pt.y;
	ScreenToClient(hw, &point);
	GetClientRect(hw, &rect);
	if(point.x > (rect.right / 2))
	{
		if(point.y < (rect.bottom / 2))
			fAllowDrop = true;
		else
			fAllowDrop = false;
	}
	else if (point.y < ((rect.bottom / 4) * 3))
		fAllowDrop = true;
	else
		fAllowDrop = false;
    if(fAllowDrop)
    {
        *pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
    }
    else
    {
        *pdwEffect = DROPEFFECT_NONE;
    }
	return S_OK;
}
/////////////////////////////////////////////////////////
HRESULT __stdcall CIDropTarget::DragLeave(void)
{
    return S_OK;
}
///////////////////////////////////////////////////////////
HRESULT __stdcall CIDropTarget::Drop(IDataObject *pDataObject, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect)
{
	RECT rect;
	POINT point;
	point.x = pt.x;
	point.y = pt.y;
	STGMEDIUM medium;
	ScreenToClient(hw, &point);
	GetClientRect(hw, &rect);
	if(point.x > (rect.right / 2))
		fAllowDrop = true;
	else if (point.y < ((rect.bottom / 4) * 3))
		fAllowDrop = true;
	else
		fAllowDrop = false;
	if(fAllowDrop)
	{
		SetCursorPos(pt.x, pt.y);
		FORMATETC fmtetc = {CF_HDROP, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
		medium.tymed = TYMED_HGLOBAL;
		medium.pUnkForRelease = NULL;
		if(pDataObject->GetData(&fmtetc, &medium) == S_OK)
			SendMessage(hw, WM_MIDROPFILES, (WPARAM) medium.hGlobal, 0);
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}
	return S_OK;
}
//////////////////////////////////////////////////////////////
HRESULT __stdcall CIDropTarget::QueryInterface(REFIID riid, void ** ppv)
{
    if (IsEqualIID(riid, IID_IDropTarget) || IsEqualIID(riid, IID_IUnknown))
	{
        *ppv = reinterpret_cast<IDropTarget*>(this);
		return S_OK;
	}
    else
	{
        *ppv = NULL;
		return E_NOINTERFACE;
	}
} 
//////////////////////////////////////////////////////////////
ULONG __stdcall CIDropTarget::AddRef(void)
{
    return (ULONG )InterlockedIncrement(&nRef); 
}
//////////////////////////////////////////////////////
ULONG __stdcall CIDropTarget::Release(void)
{
	return (ULONG) InterlockedDecrement(&nRef);
}
