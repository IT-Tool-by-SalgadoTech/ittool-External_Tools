#define CASTELLANO
#include "..\..\..\MiLibreria\h\MiLibreria.h"
//#undef CASTELLANO
/////////////////////////////////////////////////////////////////////////////
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
/////////////////////////////////////////////////////////////////////////////
#define ANCHOVENTANA 440
#define ALTOVENTANA 460
#define MARGENSEPARACION 25
#define IDBOTONEMAIL 10000
#define IDBOTONDONACION 10001
#define IDBOTONVERPAGINA 1002
/////////////////////////////////////////////////////////////////////////////
#ifdef CASTELLANO
static WCHAR JAtexto[] = L"Puede colaborar con el desarrollo de muchos modos:\r\n"
                         L"\r\n\r\n1. Si encuentra un error\r\n\tD�jeme saberlo."
                         L"\r\n\r\n2. Si el programa es �til para usted\r\n\tMe gustar�a leer su comentario."
                         L"\r\n\r\n3. Si ha encontrado un error ling��stico\r\n\tD�game algo."
                         L"\r\n\r\n4. Si tiene una sugerencia para entregas futuras\r\n\tEnv�eme su idea."
                         L"\r\n\r\n5. Desea donar a trav�s de PayPal.\r\n\tH�galo con el bot�n apropiado.";
static WCHAR JAsendmail[] = L"Pulse este bot�n para enviarme un email";
static WCHAR JAdonate[] = L"Pulse este bot�n para ir a PayPal";
static WCHAR JAverpagina[] = L"Pulse este bot�n para ver mis programas";
#else
static WCHAR JAtexto[] = L"You can collaborate with the development in many ways:\r\n"
                         L"\r\n\r\n1. If you find a bug on it\r\n\tLet me know about."
                         L"\r\n\r\n2. If this program is useful to you\r\n\tI'd like to read your comment."
                         L"\r\n\r\n3. If you have found some linguistic error\r\n\tTell me something."
                         L"\r\n\r\n4. If you want to make a suggestion for future releases\r\n\tSend me your idea."
                         L"\r\n\r\n5. You wish to donate with PayPal.\r\n\tDo it with the apropriate button.";
static WCHAR JAsendmail[] = L"Press this button to send me an email";
static WCHAR JAdonate[] = L"Press this button to go to PayPal";
static WCHAR JAverpagina[] = L"Press this button to see my programs";
#endif
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnCommandVerPagina(HWND hw, WPARAM wp, LPARAM lp)
{
    if(ShellExecute(NULL, L"open", L"https://sourceforge.net/u/untio/profile",
                    NULL, L".", SW_SHOWMAXIMIZED) < (HINSTANCE)  32)
        MiMostrarError(TEXT(__FILE__), __LINE__);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnCommandDonate(HWND hw, WPARAM wp, LPARAM lp)
{
    if(ShellExecute(NULL, L"open", L"https://www.paypal.com/cgi-bin/webscr?item_name=Donation+for+free+software+developer+Jose&cmd=_donations&business=joselopezcano%40yahoo.es&currency_code=USD",
                    NULL, L".", SW_SHOWMAXIMIZED) < (HINSTANCE)  32)
        MiMostrarError(TEXT(__FILE__), __LINE__);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnCommandEmail(HWND hw, WPARAM wp, LPARAM lp)
{
    if(ShellExecute(NULL, L"open", L"mailto:joselopezcano@yahoo.es",
                    NULL, L".", SW_SHOWMAXIMIZED) < (HINSTANCE)  32)
        MiMostrarError(TEXT(__FILE__), __LINE__);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnCommand(HWND hw, WPARAM wp, LPARAM lp)
{
	PROCESARMENSAJECOMMAND(IDBOTONVERPAGINA, JAOnCommandVerPagina, hw, wp, lp);
    PROCESARMENSAJECOMMAND(IDBOTONEMAIL, JAOnCommandEmail, hw, wp, lp);
    PROCESARMENSAJECOMMAND(IDBOTONDONACION, JAOnCommandDonate, hw, wp, lp);
    return 1;
}
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnDestroy(HWND hw, WPARAM wp, LPARAM lp)
{
    PostQuitMessage(0);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////
static LRESULT JAOnCreate(HWND hw, WPARAM wp, LPARAM lp)
{
    RECT rec;
    HINSTANCE hi;
    HWND hs;
    EJECUTARSIRETORNOIG(GetModuleHandle(NULL), NULL, hi);
    EJECUTARNORETORNOIG(GetClientRect(hw, &rec), 0);
    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"static", JAtexto, 
                        WS_VISIBLE | WS_CHILD | SS_LEFT, 
                        MARGENSEPARACION, MARGENSEPARACION,
                        (rec.right - rec.left) - (MARGENSEPARACION * 2), 
                        (rec.bottom - rec.top) - (MARGENSEPARACION * 6),
                        hw, NULL,
                        hi, NULL), NULL, hs); 
    MiPonerFuenteGui(hs);

    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"button", JAverpagina, 
                        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 
                        MARGENSEPARACION, 
                        rec.bottom - (MARGENSEPARACION * 6) ,
                        (rec.right - rec.left) - (MARGENSEPARACION * 2), 
                        MARGENSEPARACION,
                        hw, (HMENU) IDBOTONVERPAGINA,
                        hi, NULL), NULL, hs); 
    MiPonerFuenteGui(hs);
	
	
	EJECUTARSIRETORNOIG(CreateWindowEx(0, L"button", JAsendmail, 
                        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 
                        MARGENSEPARACION, 
                        rec.bottom - (MARGENSEPARACION * 4) ,
                        (rec.right - rec.left) - (MARGENSEPARACION * 2), 
                        MARGENSEPARACION,
                        hw, (HMENU) IDBOTONEMAIL,
                        hi, NULL), NULL, hs); 
    MiPonerFuenteGui(hs);
    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"button", JAdonate, 
                        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON, 
                        MARGENSEPARACION, 
                        rec.bottom - (MARGENSEPARACION * 2) ,
                        (rec.right - rec.left) - (MARGENSEPARACION * 2), 
                        MARGENSEPARACION,
                        hw, (HMENU) IDBOTONDONACION,
                        hi, NULL), NULL, hs); 
    MiPonerFuenteGui(hs);
	PARNOUSADO(lp);
	PARNOUSADO(wp);
    return 1;
}
/////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK JoseAboutFuncProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    PROCESARMENSAJE(uMsg, WM_DESTROY, JAOnDestroy, hwnd, wParam, lParam);
    PROCESARMENSAJE(uMsg, WM_CREATE, JAOnCreate, hwnd, wParam, lParam);
    PROCESARMENSAJE(uMsg, WM_COMMAND, JAOnCommand, hwnd, wParam, lParam);
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
} 
/////////////////////////////////////////////////////////////////////////////
void JoseAbout(HWND ventanaMadre, WCHAR programName[], WCHAR versionString[])
{ 
    HICON hig;//, hip;
    HCURSOR hcur;
    //WNDCLASSEX wce;
    HINSTANCE hi;
    HWND hwnd;
    WCHAR Cn[] = L"JoseAboutClass1";
    WCHAR titulo[MIMAXPATH];
#ifdef CASTELLANO
	swprintf(titulo, MIMAXPATH, L"Acerca de la versi�n %s de %s", versionString, programName);
#else
    swprintf(titulo, MIMAXPATH, L"About version %s of %s", versionString, programName);
#endif
    EJECUTARSIRETORNOIG(LoadIcon(NULL, IDI_QUESTION), NULL, hig);
    //EJECUTARSIRETORNOIG(LoadIcon(NULL, IDI_QUESTION), NULL, hip);
    EJECUTARSIRETORNOIG(LoadCursor(NULL, IDC_ARROW), NULL, hcur);
    MiWndClass mwc(CS_HREDRAW | CS_VREDRAW, JoseAboutFuncProc, hig, 
                      hcur, (HBRUSH) (COLOR_BTNFACE + 1) , NULL, 
                      Cn, NULL);
    EJECUTARSIRETORNOIG(GetModuleHandle(NULL), NULL, hi);
    EJECUTARSIRETORNOIG(CreateWindowEx(0, Cn, titulo, 
                        WS_CAPTION | WS_SYSMENU, 
                        CW_USEDEFAULT, CW_USEDEFAULT,
                        ANCHOVENTANA, ALTOVENTANA, ventanaMadre, NULL,
                        hi, NULL), NULL, hwnd);
	MiCentrarVentana(hwnd);
	/*
    EJECUTARNORETORNOIG(MoveWindow(hwnd, 
                        (GetSystemMetrics(SM_CXMAXIMIZED) - ANCHOVENTANA) / 2,
                        (GetSystemMetrics(SM_CYMAXIMIZED) - ALTOVENTANA) / 2,
                        ANCHOVENTANA, ALTOVENTANA, TRUE), 0);
    */
	ShowWindow(hwnd, SW_SHOW);
	EnableWindow(ventanaMadre, FALSE);
    MiBucleMensajes();
	MiCerrarSubVentana(hwnd, ventanaMadre);
	//UnregisterClass(Cn, hi);
}