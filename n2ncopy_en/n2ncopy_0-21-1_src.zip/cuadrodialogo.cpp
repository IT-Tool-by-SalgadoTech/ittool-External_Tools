//#include "windows.h"
#include "cabecera.h"


INT_PTR CALLBACK DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void extraerContenidoDeListView(HWND hwnd, UINT idlist, INT *cantidad, PDOBLERUTAARCHIVO *destino);
BOOL iniciarVentanaProgreso(LPDATOSDECOPIA dat, HWND hwnd);
void obtenerEstado(HWND hwnd, UINT controlid, DWORD * estado);
BOOL cdgetRadio3(void);
void eliminarPunteroLista(void * puntero);

static DATOSDECOPIA datos;
static MiListaPunteros * pdorigenes;
static INT *numorigenes;
static MiListaPunteros * pdfinales;
static INT *numdestinos;
static MiListaPunteros *pdcarpetas;
static INT *numcarpetas;
static DWORD estado1 = BST_UNCHECKED, estado2 = BST_CHECKED, estado3 = BST_CHECKED, estado4 = BST_UNCHECKED, estadoborrarlistas = BST_UNCHECKED, estadonomostrarexito = BST_UNCHECKED;
static DWORD estadonohacernada = BST_UNCHECKED;
static DWORD borrarcontenido = BST_UNCHECKED;
static BOOL muestra;


void extraerContenidoDeListViewNuevo(HWND hwnd, UINT idlist, INT *cantidad, MiListaPunteros *destino)
{
    INT canti;
    LVITEM lvi;
    if(*cantidad > 0)
    {
		destino->deletePunterosNoArray(eliminarPunteroLista);
        //delete [] (*destino);
    }
  //  ShowWindow(hwnd, SW_HIDE);
    canti = *cantidad = (INT) SendDlgItemMessage(hwnd, idlist, LVM_GETITEMCOUNT, 0, 0);
    //*destino = new RUTAARCHIVO[canti];
    //if((*destino) == 0)
    //{
    //    MessageBox(hwnd, TEXT(SZERROR), TEXT("n2ncopy.exe:"), MB_OK | MB_ICONERROR);
    //    exit(0);
    //}
    lvi.mask = LVIF_TEXT;
    lvi.iSubItem = 0;
	
	WCHAR cadena[MIMAXPATH];
    for(INT i = 0; i < canti; i++)
    {
        lvi.iItem = i;
        lvi.pszText = cadena;
        lvi.cchTextMax = sizeof(RUTAARCHIVO) - 2;
        SendDlgItemMessage(hwnd, idlist, LVM_GETITEM, 0, (LPARAM) &lvi);
		MiPathStr * mps = new MiPathStr();
		Miwcscpy(*mps, cadena);
		destino->aniadirPuntero(mps);
    }
    //ShowWindow(hwnd, SW_RESTORE);
}
///////////////////////////////////////////////////////
INT iniciarcuadrodialogo(MiListaPunteros * pddatos,
                         MiListaPunteros *pddestinos,
                         INT *contdatos,
                         INT *contdestinos,
                         HWND hwnd,
                         BOOL mostrar,
						 MiListaPunteros *pcarpetas,
						 INT *contcarpetas
						 )
{
    pdorigenes = pddatos;
    numorigenes = contdatos;
    numdestinos = contdestinos;
    pdfinales = pddestinos;
    muestra = mostrar;
	pdcarpetas = pcarpetas;
	numcarpetas = contcarpetas;
	//pdorigenes->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
	//pdfinales->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
	//pdcarpetas->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
    return((INT) DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), hwnd, DialogProc));
}
/////////////////////////////////////////
INT_PTR CALLBACK DialogProc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam)
{
	UINT mascarab;
    INT cantb;
//    LVITEM lvitb;
//    INT cantida;
//    TCHAR cad[MIMAXPATH];
//    TCHAR *principio = NULL;
//    UINT longitudprinc = 0;
//    UINT actual = 0;
//    UINT longitudfinal = 0;
//    TCHAR *final = NULL;
//    SHFILEOPSTRUCT sho;
//    TCHAR caca[200];
//	UINT mascarac;

    WPARAM parametro;
    switch(mensaje)
    {
        case WM_INITDIALOG:
            LVCOLUMN lvc;
            lvc.mask = LVCF_TEXT | LVCF_WIDTH;
            lvc.cx = 445;
            lvc.pszText = TEXT(SZELMSCOPIAR);
            SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_INSERTCOLUMN, 0, (LPARAM) &lvc);
            lvc.pszText = TEXT(SZDESTINOSCOPY);
            SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_INSERTCOLUMN, 0, (LPARAM) &lvc);
			lvc.pszText = TEXT(SZELEMSCONTENTCOPYORMOVE);
			SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_INSERTCOLUMN, 0, (LPARAM) &lvc);
            LVITEM lvi;
            lvi.mask = LVIF_TEXT;
            lvi.iSubItem = 0;
			MiPathStr * pmst;
			WCHAR cadd[MIMAXPATH];
            for(INT i = 0; i < *numorigenes; i++)
            {
                lvi.iItem = i;
				pmst = (MiPathStr *)pdorigenes->getPunteroAt(i);
				Miwcscpy(cadd, *pmst);
                lvi.pszText = cadd;
                SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_INSERTITEM, 0, (LPARAM) &lvi);
            }
            for(INT i = 0; i < *numdestinos; i++)
            {
                lvi.iItem = i;
				pmst = (MiPathStr *)pdfinales->getPunteroAt(i);
				Miwcscpy(cadd, *pmst);
                lvi.pszText = cadd;
                //lvi.pszText = (*pdfinales)[i];
                SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_INSERTITEM, 0, (LPARAM) &lvi);
            }
			for(INT i = 0; i < *numcarpetas; i++)
			{
				lvi.iItem = i;
				pmst = (MiPathStr *)pdcarpetas->getPunteroAt(i);
				Miwcscpy(cadd, *pmst);
                lvi.pszText = cadd;

				//lvi.pszText = (*pdcarpetas)[i];
				SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_INSERTITEM, 0, (LPARAM) &lvi);
			}
            SendDlgItemMessage(hwnd, IDRESCRIBIR, BM_SETCHECK, estado1, 0);
            SendDlgItemMessage(hwnd, IDRENOMBRARAUTO, BM_SETCHECK, estado2, 0);
            SendDlgItemMessage(hwnd, IDCOPIAR, BM_SETCHECK, estado3, 0);
            SendDlgItemMessage(hwnd, IDMOVER, BM_SETCHECK, estado4, 0);
			SendDlgItemMessage(hwnd, IDNOHACERNADA, BM_SETCHECK, estadonohacernada, 0);
            SendDlgItemMessage(hwnd, IDC_CHECKBOX1, BM_SETCHECK, estadoborrarlistas, 0);
            SendDlgItemMessage(hwnd, IDC_CHECKBOX2, BM_SETCHECK, estadonomostrarexito, 0);
			SendDlgItemMessage(hwnd, IDCHECKBOXERASECONTENTS, BM_SETCHECK, borrarcontenido, 0);
            SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_SETEXTENDEDLISTVIEWSTYLE,
                                LVS_EX_FULLROWSELECT,
                                LVS_EX_FULLROWSELECT);
            SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_SETEXTENDEDLISTVIEWSTYLE,
                                LVS_EX_FULLROWSELECT,
                                LVS_EX_FULLROWSELECT);
            SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_SETEXTENDEDLISTVIEWSTYLE,
                                LVS_EX_FULLROWSELECT,
                                LVS_EX_FULLROWSELECT);
            //RECT rect;
            //GetWindowRect(hwnd, &rect);
           
            if(muestra == FALSE)
            {
                parametro = IDBDOTASK;
                ShowWindow(hwnd, SW_HIDE);
                SendMessage(hwnd, WM_COMMAND, parametro, 0);
            }
            return TRUE;
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
				case IDCHECKBOXERASECONTENTS:
					obtenerEstado(hwnd, IDCHECKBOXERASECONTENTS, &borrarcontenido);
					if(borrarcontenido == BST_CHECKED)
					{
						if(MessageBox(hwnd, TEXT(SZASKBORRARCONTENIDOS), TEXT(SZTITULO), MB_YESNO | MB_ICONQUESTION) != IDYES)
						{
							SendDlgItemMessage(hwnd, IDCHECKBOXERASECONTENTS, BM_SETCHECK, BST_UNCHECKED, 0);
						}
					}
					obtenerEstado(hwnd, IDCHECKBOXERASECONTENTS, &borrarcontenido);
					return TRUE;
                case IDQUITARTODOSELEMENTOSCOPIAR:
                    SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_DELETEALLITEMS, 0, 0);
                    return TRUE;
                case IDBQUITARTODOSDESTINOS:
                    SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_DELETEALLITEMS, 0, 0);
                    return TRUE;
                case IDBQUITARTODOSELEMENTOSCOPIARINTERIOR:
                    SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_DELETEALLITEMS, 0, 0);
                    return TRUE;
                case IDQUITARSELECCIONADOSELEMENTOSCOPIAR:
                    UINT mascara;
                    INT cant;
                    cant = (INT) SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_GETITEMCOUNT, 0, 0);
                    for(INT i = 0; i < cant; i++)
                    {
//                        mascara = 0;
                        mascara = (UINT) SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_GETITEMSTATE, i, LVIS_SELECTED);
                        if(mascara & LVIS_SELECTED)
                        {
                            SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_DELETEITEM, i, 0);
                            i--;
                            --cant;
                        }
                    }
                    return TRUE;
                case IDBQUITARSELECTEDDESTINOS:
//                    UINT mascarab;
  //                  INT cantb;
                    cantb = (INT) SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_GETITEMCOUNT, 0, 0);
                    for(INT i = 0; i < cantb; i++)
                    {
                        mascarab = (UINT) SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_GETITEMSTATE, i, LVIS_SELECTED);
                        if(mascarab & LVIS_SELECTED)
                        {
                            SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_DELETEITEM, i, 0);
                            --cantb;
                            --i;
                        }
                    }
                    return TRUE;
                case IDBQUITARSELECCIONADOSELEMENTOSCOPIARINTERIOR:
//                    UINT mascarab;
  //                  INT cantb;
                    cantb = (INT) SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_GETITEMCOUNT, 0, 0);
                    for(INT i = 0; i < cantb; i++)
                    {
                        mascarab = (UINT) SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_GETITEMSTATE, i, LVIS_SELECTED);
                        if(mascarab & LVIS_SELECTED)
                        {
                            SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_DELETEITEM, i, 0);
                            --cantb;
                            --i;
                        }
                    }
                    return TRUE;
                case IDBVOLVERAVENTANITA:
                    obtenerEstado(hwnd, IDRESCRIBIR, &estado1);
                    obtenerEstado(hwnd, IDRENOMBRARAUTO, &estado2);
                    obtenerEstado(hwnd, IDCOPIAR, &estado3);
                    obtenerEstado(hwnd, IDMOVER, &estado4);
					obtenerEstado(hwnd, IDNOHACERNADA, &estadonohacernada);
                    obtenerEstado(hwnd, IDC_CHECKBOX1, &estadoborrarlistas);
                    obtenerEstado(hwnd, IDC_CHECKBOX2, &estadonomostrarexito);
					obtenerEstado(hwnd, IDCHECKBOXERASECONTENTS, &borrarcontenido);
                    *numorigenes = 0;
                    *numdestinos = 0;
					*numcarpetas = 0;
					pdorigenes->deletePunterosNoArray(eliminarPunteroLista);
					pdfinales->deletePunterosNoArray(eliminarPunteroLista);
					pdcarpetas->deletePunterosNoArray(eliminarPunteroLista);
                    extraerContenidoDeListViewNuevo(hwnd, IDLISTELEMSCOPIAR, numorigenes, pdorigenes);
                    extraerContenidoDeListViewNuevo(hwnd, IDLISTADESTINOSCOPIAR, numdestinos, pdfinales);
					extraerContenidoDeListViewNuevo(hwnd, IDLISTACONTENIDOSCOPIAR, numcarpetas, pdcarpetas);
                   
                    EndDialog(hwnd, 1);
                    return TRUE;
                case IDBSALIRDELPROGRAMA:
                    if(*numdestinos > 0)
                        pdfinales->deletePunterosNoArray(eliminarPunteroLista);
                    if(*numorigenes > 0)
                        pdorigenes->deletePunterosNoArray(eliminarPunteroLista);
					if(*numcarpetas > 0)
						pdcarpetas->deletePunterosNoArray(eliminarPunteroLista);
                    
                    EndDialog(hwnd, SALIR);
                    return TRUE;
//                    break;
                case IDBDOTASK:
                    if((SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_GETITEMCOUNT, 0, 0) == 0) &&
						(SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_GETITEMCOUNT, 0, 0) == 0))
                    {
                        MessageBox(hwnd,
                                    TEXT(SZNOITEMTOWORK),
                                    SZPFLEAESTO,
                                    MB_OK | MB_ICONINFORMATION);
                        if(muestra == FALSE)
                        {
//                            muestra = TRUE;
                            
                            EndDialog(hwnd, 1);
                        }
                        return TRUE;
                    }
                    if(SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_GETITEMCOUNT, 0, 0) == 0)
                    {
                        MessageBox(hwnd,
                                    TEXT(SZNOTARGET),
                                    SZPFLEAESTO,
                                    MB_OK | MB_ICONINFORMATION);
                        if(muestra == FALSE)
                        {
                            
                            EndDialog(hwnd, 1);
                        }
                        return TRUE;
                    }
					//MiListaPunteros * lpp;
					//lpp = datos.listaArchivos;
                    memset(&datos, 0, sizeof(datos));
					datos.listaArchivos = pdorigenes;
					datos.listadestinos = pdfinales;
					datos.listacarpetas = pdcarpetas;
					pdorigenes->deletePunterosNoArray(eliminarPunteroLista);
					pdfinales->deletePunterosNoArray(eliminarPunteroLista);
					pdcarpetas->deletePunterosNoArray(eliminarPunteroLista);
                    extraerContenidoDeListViewNuevo(hwnd, IDLISTELEMSCOPIAR, &(datos.numdatos), datos.listaArchivos);
                    extraerContenidoDeListViewNuevo(hwnd, IDLISTADESTINOSCOPIAR, &(datos.numdestinos), datos.listadestinos);
					extraerContenidoDeListViewNuevo(hwnd, IDLISTACONTENIDOSCOPIAR, &(datos.numcarpetas), datos.listacarpetas);
                    datos.renombrar = datos.nohacernada = datos.sobreescribir = datos.mover = FALSE;
					if(SendDlgItemMessage(hwnd, IDNOHACERNADA, BM_GETCHECK, 0, 0) == BST_CHECKED)
                        datos.nohacernada = TRUE;
                    if(SendDlgItemMessage(hwnd, IDRESCRIBIR, BM_GETCHECK, 0, 0) == BST_CHECKED)
                        datos.sobreescribir = TRUE;
                    if(SendDlgItemMessage(hwnd, IDRENOMBRARAUTO, BM_GETCHECK, 0, 0) == BST_CHECKED)
                        datos.renombrar = TRUE;
                    if(SendDlgItemMessage(hwnd, IDMOVER, BM_GETCHECK, 0, 0) == BST_CHECKED)
                        datos.mover = TRUE;
                    if(SendDlgItemMessage(hwnd, IDCHECKBOXERASECONTENTS, BM_GETCHECK, 0, 0) == BST_CHECKED)
						datos.BorrarContenidoDestinos = TRUE;
					borrarcontenido = (DWORD) SendDlgItemMessage(hwnd, IDCHECKBOXERASECONTENTS, BM_GETCHECK, 0, 0);
					estadoborrarlistas = (DWORD) SendDlgItemMessage(hwnd, IDC_CHECKBOX1, BM_GETCHECK, 0, 0);
                    estadonomostrarexito = (DWORD) SendDlgItemMessage(hwnd, IDC_CHECKBOX2, BM_GETCHECK, 0, 0);
                    //obtenerEstado(hwnd, IDC_CHECKBOX1, &estadoborrarlistas);
                    ShowWindow(hwnd, SW_HIDE);
                    if (iniciarVentanaProgreso(&datos, hwnd) == TRUE)
                    {
                        //MessageBox(NULL, TEXT("CC"), TEXT("CCCC"), MB_OK);
                        if(estadoborrarlistas == BST_CHECKED)
                        {
                            if(SendDlgItemMessage(hwnd, IDLISTELEMSCOPIAR, LVM_DELETEALLITEMS, 0, 0) == FALSE)
                                MostrarError(TEXT(__FILE__), __LINE__);
                            if(SendDlgItemMessage(hwnd, IDLISTADESTINOSCOPIAR, LVM_DELETEALLITEMS, 0, 0) == FALSE)
                                MostrarError(TEXT(__FILE__), __LINE__);
                            if(SendDlgItemMessage(hwnd, IDLISTACONTENIDOSCOPIAR, LVM_DELETEALLITEMS, 0, 0) == FALSE)
                                MostrarError(TEXT(__FILE__), __LINE__);
                        }
                        if(estadonomostrarexito != BST_CHECKED)
                            MessageBox(hwnd, TEXT(SZTAREATERMINADA), SZPFLEAESTO, MB_OK |  MB_ICONINFORMATION);
                    }
                    else
                    {

                        MessageBox(hwnd, TEXT(SZTAREAINTERRUMPIDA), SZPFLEAESTO, MB_OK |  MB_ICONEXCLAMATION);
                    }
                    if(muestra == FALSE)
                    {
                        //MessageBeep(0xffffffff);
                      //  muestra = TRUE;
                        *numorigenes = 0;
                        *numdestinos = 0;
						*numcarpetas = 0;
						pdorigenes->deletePunterosNoArray(eliminarPunteroLista);
						pdfinales->deletePunterosNoArray(eliminarPunteroLista);
						pdcarpetas->deletePunterosNoArray(eliminarPunteroLista);
                        extraerContenidoDeListViewNuevo(hwnd, IDLISTELEMSCOPIAR, numorigenes, pdorigenes);
                        extraerContenidoDeListViewNuevo(hwnd, IDLISTADESTINOSCOPIAR, numdestinos, pdfinales);
                        extraerContenidoDeListViewNuevo(hwnd, IDLISTACONTENIDOSCOPIAR, numcarpetas, pdcarpetas);
                       
                        EndDialog(hwnd, 1);
                        return TRUE;
                    }

                    ShowWindow(hwnd, SW_SHOW);

                    return TRUE;
                default:
                    return FALSE;
            }
//            return TRUE;
        default:
        {
          PARNOUSADO(lParam);
            return FALSE;
        }
    }
//    return FALSE;
}
///////////////////////////////////////////////////////////
void extraerContenidoDeListView(HWND hwnd, UINT idlist, INT *cantidad, PDOBLERUTAARCHIVO *destino)
{
    INT canti;
    LVITEM lvi;
    if(*cantidad > 0)
    {
        delete [] (*destino);
    }
  //  ShowWindow(hwnd, SW_HIDE);
    canti = *cantidad = (INT) SendDlgItemMessage(hwnd, idlist, LVM_GETITEMCOUNT, 0, 0);
    *destino = new RUTAARCHIVO[canti];
    if((*destino) == 0)
    {
        MessageBox(hwnd, TEXT(SZERROR), TEXT("n2ncopy.exe:"), MB_OK | MB_ICONERROR);
        exit(0);
    }
    lvi.mask = LVIF_TEXT;
    lvi.iSubItem = 0;
    for(INT i = 0; i < canti; i++)
    {
        lvi.iItem = i;
        lvi.pszText = (*destino)[i];
        lvi.cchTextMax = sizeof(RUTAARCHIVO) - 2;
        SendDlgItemMessage(hwnd, idlist, LVM_GETITEM, 0, (LPARAM) &lvi);
    }
    //ShowWindow(hwnd, SW_RESTORE);
}
///////////////////////////////////////////////////////
void obtenerEstado(HWND hwnd, UINT controlid, DWORD * estado)
{
    *estado = (DWORD) SendDlgItemMessage(hwnd, controlid, BM_GETCHECK, 0, 0);
}
///////////////////////////////////////////////////////////////
BOOL cdgetRadio3(void)
{
    if(estado3 == BST_CHECKED)
        return TRUE;
    return FALSE;
}
/////////////////////////////////////////////////////////
void cdsetEstado(BOOL est3, BOOL est4)
{
    estado3 = est3;
    estado4 = est4;
}

