#include "cabecera.h"
#include "miole.h"

#pragma comment(lib, "Shlwapi.lib")

#define ANCHOVENTANITA 170
#define ALTOVENTANITA 95

void EscribirCantidadDeElementos(MiListaPunteros * mlp, HDC hdc, COLORREF colfondo, INT cx, INT cy);

INT iniciarcuadrodialogo(MiListaPunteros *pddatos,
                         MiListaPunteros *pddestinos,
                         INT *contdatos,
                         INT *contdestinos,
                         HWND hwnd,
                         BOOL mostrar,
						 MiListaPunteros *pcarpetas,
						 INT *contcarpetas);
void cdsetEstado(BOOL est3, BOOL est4);

void JoseAbout(HWND ventanaMadre, WCHAR programName[], WCHAR versionString[]);
static BOOL escorrectoparalistaorigenescarpetas(TCHAR * cadena, HWND hwnd);
static void AnnadirFilesALista(HWND hwnd);
UINT_PTR CALLBACK MiOFNHookProc(HWND hdlg, UINT uiMsg, WPARAM wParam, LPARAM lParam);
static BOOL maExaminarDirectorio(MiPathStr & directorioexaminado, HWND hventmadre);
static void maMostrarMenuContextual(HWND hwnd, INT coox, INT cooy);
static void aniadirdirectoriodestino(TCHAR *cadena, HWND);
static void aniadircontenidodedirectorio(TCHAR * cadena, IShellFolder * * fold, LPITEMIDLIST ** pil, INT *);
//static void EscribirNumeroDeElementos(HWND, HDC , COLORREF colfondo, INT cx, INT cy);
static BOOL destinosenorigen2(TCHAR *origen, TCHAR *salida);
static BOOL destinoenorigenes2(TCHAR *destino, TCHAR *salida);
static BOOL origenestaendestino(TCHAR *origen, TCHAR *destino);
static BOOL destinoenorigenes(TCHAR *destino, TCHAR *);
static BOOL destinosenorigen(TCHAR *origen, TCHAR *);
static BOOL destinoestaenorigen(TCHAR *destino, TCHAR *origen);

static BOOL escorrectoparalistaorigenespuros(TCHAR * cadena, HWND hwnd);
BOOL cdgetRadio3(void);

static MiListaPunteros listaCarpetas;
static MiListaPunteros listaArchivos;
static MiListaPunteros listaDestinos; 


//static RUTAARCHIVO * pcarpetas;
static INT numarchivos;
static INT numdestinos;
static INT numcarpetas;
static INT AnchoPantalla;
static INT AltoPantalla;
static BOOL muestra = TRUE;
static BOOL estapulsado = FALSE;
static INT cx, cy;
static RECT rect1;

/////////////////////////////////////////////////////////
void eliminarPunteroLista(void * puntero)
{
	MiPathStr * pmp;
	pmp = (MiPathStr *) puntero;
	delete(pmp);
}
/////////////////////////////////////////////////////////
int comparar(void * p1, void * p2)
{
	MiPathStr ** ps1, **ps2;
	WCHAR c1[MIMAXPATH];
	WCHAR c2[MIMAXPATH];
	ps1 = (MiPathStr **) p1;
	ps2 = (MiPathStr **) p2;
	wcscpy(c1, **ps1);
	wcscpy(c2, **ps2);
	return(_wcsicmp(c1, c2));
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnLButtonUp(HWND hw, WPARAM wp, LPARAM lp)
{
    estapulsado = FALSE; 
	PARNOUSADO(hw);
	PARNOUSADO(wp);
	PARNOUSADO(lp);
    return 0;
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnMouseLeave(HWND hw, WPARAM wp, LPARAM lp)
{
    estapulsado = FALSE;
    return 0;
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnContextMenu(HWND hw, WPARAM wp, LPARAM lp)
{
    maMostrarMenuContextual(hw, LOWORD(lp), HIWORD(lp));
    return 0;
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnDestroy(HWND hw, WPARAM wp, LPARAM lp)
{
    EJECUTARNORETORNODI(RevokeDragDrop(hw), S_OK);
    PostQuitMessage (0);      
    return 0;
}

/////////////////////////////////////////////////////////
LRESULT CALLBACK OnMiDropFiles(HWND hw, WPARAM wp, LPARAM lp)
{
           
    HDROP hd;
    POINT pt;
    RECT rect, rect2;
    MiPathStr cadena;
    UINT h, i;
    DWORD finf;
    hd = (HDROP) wp;
    if (DragQueryPoint(hd, &pt) == 0)
    {
        DragFinish(hd);
        MessageBeep(0xffffffff);
        return 0;
    }
	EJECUTARNORETORNOIG(GetCursorPos(&pt), 0);
	EJECUTARNORETORNOIG(ScreenToClient(hw, &pt), 0);
    EJECUTARNORETORNOIG(GetClientRect(hw, &rect2), 0);
    if((pt.y >  (rect2.bottom / 4) * 3) && (pt.y < rect2.bottom))
    {
        if((pt.x > (0)) && (pt.x < (rect2.right / 2)))
        {
            DragFinish(hd);
            return 0;
        }
    }
    h = DragQueryFile(hd, 0xffffffff, NULL, 0);
    for (i = 0; i <  h; i++)
    {
        DragQueryFile(hd, i, cadena, (MIMAXPATH) - 2);
        EJECUTARNORETORNOIG(GetClientRect(hw, &rect), 0);
        if (pt.x > (rect.right / 2))
            aniadirdirectoriodestino(cadena, hw);
        else if ((pt.x < (rect.right / 2)) && (pt.y > rect.bottom / 2) && (pt.y < rect.bottom - rect.bottom / 4))
        {
            finf = GetFileAttributesHechaPorMi(cadena);
            if (finf & FILE_ATTRIBUTE_DIRECTORY)
            {
				if(escorrectoparalistaorigenescarpetas(cadena, hw) == TRUE)
				{
					MiPathStr * cadenaperm = new MiPathStr();
					wcscpy(*cadenaperm, cadena);
					listaCarpetas.aniadirPuntero((void *) cadenaperm);
					//SendMessage(hlistaCarpetas, LB_ADDSTRING, 0, (LPARAM) cadena);
				}
            }
            else if (escorrectoparalistaorigenespuros(cadena, hw) == TRUE)
            {
					MiPathStr * cadenaperm = new MiPathStr();
					wcscpy(*cadenaperm, cadena);
					listaArchivos.aniadirPuntero((void *) cadenaperm);

//				SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_ADDSTRING, 0, (LPARAM) cadena);
            }

        }
        else
        {
            if (escorrectoparalistaorigenespuros(cadena, hw) == TRUE)
			{
					MiPathStr * cadenaperm = new MiPathStr();
					wcscpy(*cadenaperm, cadena);
					listaArchivos.aniadirPuntero((void *) cadenaperm);
			}
             //       SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_ADDSTRING, 0, (LPARAM) cadena);
        }
    }
    EJECUTARNORETORNOIG(InvalidateRect(hw, NULL, TRUE), 0);
    DragFinish(hd);
    return 0;
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnLButtonDblClk(HWND hw, WPARAM wp, LPARAM lp)
{       
    INT respuesta;
	numarchivos = (INT) listaArchivos.getPunterosCount();
//	listaArchivos.ordenarPunteros((funcionComparadoraMiListaPunteros) &comparar);
    numdestinos = listaDestinos.getPunterosCount();
//    listaDestinos.ordenarPunteros((funcionComparadoraMiListaPunteros) &comparar);
    numcarpetas = listaCarpetas.getPunterosCount();
//	listaCarpetas.ordenarPunteros((funcionComparadoraMiListaPunteros) &comparar);
    ShowWindow(hw, SW_HIDE);
    EJECUTARNORETORNOIG(SetWindowPos(hw, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE), 0);
    respuesta = iniciarcuadrodialogo(&listaArchivos, &listaDestinos, &numarchivos, &numdestinos, hw, muestra, &listaCarpetas, &numcarpetas);
    EJECUTARNORETORNOIG(SetWindowPos(hw, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE), 0);
    muestra = TRUE;
    if (respuesta == SALIR)
    {
        EJECUTARNORETORNOIG(DestroyWindow(hw), 0);
		return 0;
	}
    else
    {
		ShowWindow(hw, SW_SHOW);
        EJECUTARNORETORNOIG(InvalidateRect(hw, NULL, TRUE), 0);
    }
    return 0;
}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnPaint(HWND hw, WPARAM wp, LPARAM lp)
{
    PAINTSTRUCT ps;
    HDC hdc;
    HBRUSH hbv, hba, hb, hbvc, hbbl;
    HPEN hpv, hpa, hp, hpvc, hpb;
    RECT rect;
    MiPathStr cadena;
    EJECUTARSIRETORNOIG(BeginPaint(hw, &ps), NULL, hdc);
    EJECUTARSIRETORNOIG(CreateSolidBrush(RGB(79, 255, 0)), NULL, hbv);
    EJECUTARSIRETORNOIG(CreateSolidBrush(RGB(55, 155, 255)), NULL, hba);
    EJECUTARSIRETORNOIG(CreateSolidBrush(RGB(0, 205, 0)), NULL, hbvc);
    EJECUTARSIRETORNOIG(CreateSolidBrush(RGB(0, 255, 0)), NULL, hbbl);
    EJECUTARSIRETORNOIG(CreatePen(PS_SOLID, 0, RGB(79,255, 0)), NULL, hpv);
    EJECUTARSIRETORNOIG(CreatePen(PS_SOLID, 0, RGB(55, 155, 255)), NULL, hpa);
    EJECUTARSIRETORNOIG(CreatePen(PS_SOLID, 0, RGB(0, 255, 0)), NULL, hpb);
    EJECUTARSIRETORNOIG(CreatePen(PS_SOLID, 0, RGB(0,205, 0)), NULL, hpvc);
    EJECUTARNORETORNOIG(GetClientRect(hw, &rect), 0);
    EJECUTARSIRETORNOIG((HBRUSH) (HGDIOBJ) SelectObject(hdc, hbv), NULL, hb);
    EJECUTARSIRETORNOIG( (HPEN) (HGDIOBJ) SelectObject(hdc, hpv), NULL, hp);
    EJECUTARNORETORNOIG(Rectangle(hdc, 0, 0, rect.right / 2, rect.bottom), 0);
    EJECUTARNORETORNOIG(SelectObject(hdc, hbvc), NULL);
    EJECUTARNORETORNOIG(SelectObject(hdc, hpvc), NULL);
    EJECUTARNORETORNOIG(Rectangle(hdc, 0, rect.bottom / 2, rect.right / 2, rect.bottom - rect.bottom / 4), 0);
    //EscribirNumeroDeElementos(GetDlgItem(hw, IDLISTAARCHIVOS), hdc, RGB(79, 255, 0), 0, 5);
	EscribirCantidadDeElementos(&listaArchivos, hdc, RGB(79, 255, 0), 0, 5);
	EscribirCantidadDeElementos(&listaCarpetas, hdc, RGB(0, 205, 0), 0, rect.bottom / 2);
	//EscribirNumeroDeElementos(hlistaCarpetas, hdc, RGB(0, 205, 0), 0, rect.bottom / 2);
	EJECUTARNORETORNOIG(SelectObject(hdc, hba), NULL);
    EJECUTARNORETORNOIG(SelectObject(hdc, hpa), NULL);
    EJECUTARNORETORNOIG(Rectangle(hdc, rect.right / 2, 0, rect.right, rect.bottom), 0);
	EscribirCantidadDeElementos(&listaDestinos, hdc, RGB(55, 155, 255), rect.right / 2, 5);
    //EscribirNumeroDeElementos(hlistaDestinos, hdc, RGB(55, 155, 255), rect.right / 2, 5);
    EJECUTARNORETORNOIG(SelectObject(hdc, hbbl), NULL);
    EJECUTARNORETORNOIG(SelectObject(hdc, hpb), NULL);
    EJECUTARNORETORNOIG(Rectangle(hdc, 0, (rect.bottom / 4) * 3, rect.right / 2 , rect.bottom), 0);
    EJECUTARNORETORNOIG(SelectObject(hdc, hb), NULL);
    EJECUTARNORETORNOIG(SelectObject(hdc, hp), NULL);
    EJECUTARNORETORNOIG(DeleteObject(hpa), 0);
    EJECUTARNORETORNOIG(DeleteObject(hpv), 0);
    EJECUTARNORETORNOIG(DeleteObject(hbv), 0);
    EJECUTARNORETORNOIG(DeleteObject(hpvc), 0);
    EJECUTARNORETORNOIG(DeleteObject(hbvc), 0);
    EJECUTARNORETORNOIG(DeleteObject(hba), 0);
    EndPaint(hw, &ps);
    EJECUTARNORETORNOIG(MoveWindow(GetDlgItem(hw, IDBOTONCOPIAR), rect.right / 2, rect.bottom / 2, rect.right / 2, rect.bottom / 4, TRUE), 0);
    EJECUTARNORETORNOIG(MoveWindow(GetDlgItem(hw, IDBOTONBORRAR), rect.right / 2, rect.bottom - (rect.bottom / 4), rect.right / 2, rect.bottom / 4, TRUE), 0);
    if(cdgetRadio3() == TRUE)
        cadena = SZCOPY;
    else
        cadena = SZMOVE;
    SendDlgItemMessage(hw, IDBOTONCOPIAR, WM_SETTEXT, 0, (LPARAM) cadena);
    SendDlgItemMessage(hw, IDBOTONBORRAR, WM_SETTEXT, 0, (LPARAM) SZBORRARLISTAS);
    SetFocus(hw);
    return 0;

}
/////////////////////////////////////////////////////////
LRESULT CALLBACK OnSizing(HWND hw, WPARAM wp, LPARAM lp)
{
    LPRECT prect;
    prect = (LPRECT) lp;
	INT anchov, altov;
	anchov = ANCHOVENTANITA * 2;
	altov = ALTOVENTANITA * 2;
    if((prect->right - prect->left) > anchov)
    {
        if(prect->left < rect1.left)
        {
            rect1.right = prect->right = prect->left + anchov;
            rect1.left = rect1.right - anchov;
        }
        if(prect->right > rect1.right)
        {
            rect1.left = prect->left = prect->right - anchov;
            rect1.right = rect1.left + anchov;
        }
    }
    if((prect->bottom - prect->top) > altov)
    {
        if(prect->top < rect1.top)
        {
            rect1.bottom = prect->bottom = prect->top + altov;
            rect1.top = rect1.bottom - altov;
        }
        if(prect->bottom > rect1.bottom)
        {
            rect1.top = prect->top = prect->bottom - altov;
            rect1.bottom = rect1.top + altov;
        }
    }
    EJECUTARNORETORNOIG(InvalidateRect(hw, NULL, FALSE), 0);
    return TRUE;
}
////////////////////////////////////////////////////////////
LRESULT CALLBACK OnMouseMove(HWND hw, WPARAM wp, LPARAM lp)
{
    LPITEMIDLIST rd;
    INT indice;
    IShellFolder * sf, *fold;
    INT  cont, cont2;
    LPITEMIDLIST * pil;
    MiPathStr cadena;
    IDataObject *ido;
    CIDropSource * ds;
    DWORD sal, ret;
	INT iii;
    if(estapulsado == FALSE)
        return 0;
    //EJECUTARSIRETORNOIG((INT) SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_GETCOUNT, 0, 0), LB_ERR, cont);
	cont = listaArchivos.getPunterosCount();
	cont2 = listaCarpetas.getPunterosCount();
	//    EJECUTARSIRETORNOIG((INT) SendDlgItemMessage(hw, IDLISTACARPETAS, LB_GETCOUNT, 0, 0), LB_ERR, cont2);
    if((cont == 0) && (cont2 == 0))
    {
        estapulsado = FALSE;
        return 0;
    }
    EJECUTARNORETORNODI(SHGetDesktopFolder(&sf), NOERROR);
    EJECUTARNORETORNODI(SHGetSpecialFolderLocation(NULL, CSIDL_DRIVES, &rd), S_OK);
    EJECUTARNORETORNODI(sf->BindToObject(rd, NULL, IID_IShellFolder, (void **) &fold), S_OK);
    pil = (LPITEMIDLIST *) Mimalloc(sizeof(LPITEMIDLIST) * cont);
	indice = 0;
    for(indice = 0; indice < cont; indice++)
    {
		MiPathStr * pp;
		pp = (MiPathStr *) listaArchivos.getPunteroAt(indice);
		cadena = *pp;
        //EJECUTARNORETORNOIG(SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_GETTEXT, indice, (LPARAM) cadena),LB_ERR);
        EJECUTARNORETORNODI(fold->ParseDisplayName(NULL, NULL, cadena, NULL, &(pil[indice]), NULL), S_OK);
    }
	iii = indice + 1;
	MiPathStr * mpst;
    for(indice = 0; indice < cont2; indice++)
	{
		mpst = (MiPathStr *) listaCarpetas.getPunteroAt(indice);
		Miwcscpy(cadena, *mpst);
	    //EJECUTARNORETORNOIG(SendMessage(hlistaCarpetas, LB_GETTEXT, indice, (LPARAM) cadena), LB_ERR);
		aniadircontenidodedirectorio(cadena, &fold, &pil, &iii);
	}
	if(iii > 1)
	{
        EJECUTARNORETORNODI(fold->GetUIObjectOf( NULL, (UINT) iii - 1, (LPCITEMIDLIST *) &(pil[0]),  IID_IDataObject, NULL, (void **) &ido), S_OK);
        ds = new CIDropSource;
        ret = DoDragDrop(reinterpret_cast<IDataObject *> (ido),reinterpret_cast<IDropSource*> (ds), DROPEFFECT_COPY | DROPEFFECT_MOVE, &sal);
        if (ret == DRAGDROP_S_DROP)
        {
            if(!(sal & DROPEFFECT_COPY))
            {
                //SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_RESETCONTENT, 0, 0);
				//for(unsigned int x = 0; x < listaCarpetas.getPunterosCount(); x++)
				//	free(listaCarpetas.getPunteroAt(x));
	    		//SendMessage(hlistaCarpetas, LB_RESETCONTENT, 0, 0);
				listaArchivos.deletePunterosNoArray(eliminarPunteroLista);
				listaCarpetas.deletePunterosNoArray(eliminarPunteroLista);
                EJECUTARNORETORNOIG(InvalidateRect(hw, NULL, TRUE), 0);
            }
        }
        fold->Release();
        sf->Release();
        ido->Release();
        delete ds;
	}
    estapulsado = FALSE;
    for(indice = 0; indice < (iii - 1); indice++)
        CoTaskMemFree(pil[indice]);
    free(pil);
    return 0;
}
////////////////////////////////////////////////////
LRESULT CALLBACK OnLButtonDown(HWND hw, WPARAM wp, LPARAM lp)
{
    RECT rect;
    EJECUTARNORETORNOIG(GetClientRect(hw, &rect), 0);
    cx = LOWORD(lp);
    cy = HIWORD(lp);
    if((cy > (rect.bottom - rect.bottom / 4)) && (cy < rect.bottom))
    {
        if((cx > 0) && (cx < (rect.right / 2)))
            estapulsado = TRUE;
    }
    else
        estapulsado = FALSE;
    return 0;
}
///////////////////////////////////////////////////////
LRESULT CALLBACK OnCommandBorrar(HWND hw, WPARAM wp, LPARAM lp)
{
//	int ii;
	listaArchivos.deletePunterosNoArray(eliminarPunteroLista);
    //SendDlgItemMessage(hw, IDLISTAARCHIVOS, LB_RESETCONTENT, 0, 0);
	listaDestinos.deletePunterosNoArray(eliminarPunteroLista);
    //SendDlgItemMessage(hw, IDLISTADESTINOS, LB_RESETCONTENT, 0, 0);
	//for(ii = 0; ii < (int) listaCarpetas.getPunterosCount(); ii++)
	//{
	//	delete listaCarpetas.getPunteroAt(ii);
	//}
	listaCarpetas.deletePunterosNoArray(eliminarPunteroLista);

	//SendDlgItemMessage(hw, IDLISTACARPETAS, LB_RESETCONTENT, 0, 0);
    InvalidateRect(hw, NULL, TRUE);
    SetFocus(hw);
    return 0;
}
/////////////////////////////////////////////////
LRESULT CALLBACK OnCommandCopiar(HWND hw, WPARAM wp, LPARAM lp)
{
    muestra = FALSE;
    SendMessage(hw, WM_LBUTTONDBLCLK, 0, 0);
    SetFocus(hw);
    return 0;
}
/////////////////////////////////////////////////
LRESULT CALLBACK OnCommand(HWND hw, WPARAM wp, LPARAM lp)
{
    PROCESARMENSAJECOMMAND(IDBOTONCOPIAR, OnCommandCopiar, hw, wp, lp);
    PROCESARMENSAJECOMMAND(IDBOTONBORRAR, OnCommandBorrar, hw, wp, lp);
    return 1;
}
/////////////////////////////////////////////////
LRESULT CALLBACK OnCreate(HWND hw, WPARAM wp, LPARAM lp)
{
    TRACKMOUSEEVENT tme;
    MiPathStr cadena;
    HWND hcon;
    EJECUTARNORETORNOIG(GetWindowRect(hw, &rect1), 0);
//    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"LISTBOX", 
//        NULL, LBS_STANDARD|WS_CHILD|WS_DISABLED|LBS_HASSTRINGS,
//        0, 0, 20, 70, hw, (HMENU) IDLISTAARCHIVOS, GetModuleHandle(NULL), 
//        NULL), NULL, hlistaArchivos);
//    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"LISTBOX", NULL,
//        LBS_STANDARD|WS_CHILD|WS_DISABLED|LBS_HASSTRINGS,
//        60, 0, 20, 70, hw, (HMENU) IDLISTADESTINOS, GetModuleHandle(NULL),
//        NULL), NULL, hlistaDestinos);
//    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"LISTBOX", NULL, 
  //      LBS_STANDARD|WS_CHILD|WS_DISABLED|LBS_HASSTRINGS,
    //    100, 0, 20, 70, hw, (HMENU) IDLISTACARPETAS, GetModuleHandle(NULL), 
//        NULL), NULL, hlistaCarpetas);
    tme.cbSize = sizeof(TRACKMOUSEEVENT);
    tme.dwFlags = TME_LEAVE;
    tme.hwndTrack = hw;
    tme.dwHoverTime = HOVER_DEFAULT;
    EJECUTARNORETORNOIG(TrackMouseEvent(&tme), FALSE);
    EJECUTARNORETORNOIG(GetClientRect(hw, &rect1), 0);
    if(cdgetRadio3() == TRUE)
        cadena = SZCOPY;
    else
        cadena = SZMOVE;
    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"BUTTON", cadena,
        WS_CHILD |  WS_VISIBLE | BS_PUSHBUTTON,
        rect1.right / 2, rect1.bottom / 2, rect1.right / 2, rect1.bottom / 4, hw,
        (HMENU) IDBOTONCOPIAR, GetModuleHandle(NULL), NULL), NULL, hcon);
    MiPonerFuenteGui(hcon);
    EJECUTARSIRETORNOIG(CreateWindowEx(0, L"BUTTON", SZBORRARLISTAS,
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        rect1.right / 2, rect1.bottom - (rect1.bottom / 4), rect1.right / 2,
        rect1.bottom / 4, hw,
        (HMENU) IDBOTONBORRAR, GetModuleHandle(NULL), NULL), NULL, hcon);
    MiPonerFuenteGui(hcon);
    return 0;
}
/////////////////////////////////////////////////
LRESULT CALLBACK MiFuncionDeVentana(HWND hw, UINT mes, WPARAM wp, LPARAM lp)
{
    PROCESARMENSAJE(mes, WM_LBUTTONUP, OnLButtonUp, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_MOUSELEAVE, OnMouseLeave, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_CONTEXTMENU, OnContextMenu, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_DESTROY, OnDestroy, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_MIDROPFILES, OnMiDropFiles, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_LBUTTONDBLCLK, OnLButtonDblClk, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_PAINT, OnPaint, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_SIZING, OnSizing, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_MOUSEMOVE, OnMouseMove, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_LBUTTONDOWN, OnLButtonDown, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_COMMAND, OnCommand, hw, wp, lp);
    PROCESARMENSAJE(mes, WM_CREATE, OnCreate, hw, wp, lp);
    return DefWindowProc (hw, mes, wp, lp);
}
/////////////////////////////////////////////////
int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nCmdShow)
{
    WCHAR szClassName[ ] = L"n2ncopyWindowsApp";
    HWND hwnd;              
    //WNDCLASSEX wincl;    
    RECT rect1;
    INT retor;
    HICON hip, hig;
    HCURSOR hcur;
    EJECUTARSIRETORNOIG(LoadIcon(hThisInstance, MAKEINTRESOURCE(ICONOGRANDE)), NULL, hig);
    EJECUTARSIRETORNOIG(LoadIcon(hThisInstance, MAKEINTRESOURCE(ICONOGRANDE)), NULL, hip);
    EJECUTARSIRETORNOIG(LoadCursor(NULL, IDC_ARROW), NULL, hcur);
    MiWndClass mwc(CS_DBLCLKS, MiFuncionDeVentana, hig, 
                      hcur, (HBRUSH) (COLOR_BACKGROUND + 1), NULL, 
                      szClassName, hip);
    MiIniciarControlesComunes();
	INICIAOLE
    EJECUTARNORETORNOIG(SystemParametersInfo(SPI_GETWORKAREA, 0, &rect1, 0), 0);
    AltoPantalla = rect1.bottom;
    AnchoPantalla = rect1.right;
    EJECUTARSIRETORNOIG(CreateWindowEx(
               WS_EX_TOPMOST,            
               szClassName,         
               L"n2ncopy.exe",       
               WS_OVERLAPPED|WS_THICKFRAME | WS_SYSMENU, 
               rect1.right - ANCHOVENTANITA,       
               rect1.bottom - ALTOVENTANITA,       
               ANCHOVENTANITA,
               ALTOVENTANITA,
               HWND_DESKTOP,        
               NULL,                
               hThisInstance,       
               NULL                 
           ), NULL, hwnd);
    ShowWindow (hwnd, nCmdShow);
	CIDropTarget midroptarget(hwnd);
	EJECUTARNORETORNODI(RegisterDragDrop(hwnd, &midroptarget), S_OK);
    retor = MiBucleMensajes();
    PARNOUSADO(hPrevInstance);
    PARNOUSADO(lpszArgument);
    return retor;
}
/////////////////////////////////////////
BOOL destinoenorigenes2(TCHAR *destino, MiPathStr & salida)
{
    INT v;
	v = (INT) listaArchivos.getPunterosCount();//SendMessage(hlistaArchivos, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
    MiPathStr * pcad;
	for (int w = 0; w < v; w++)
    {
		pcad = (MiPathStr *) listaArchivos.getPunteroAt(w);
		cadena2 = *pcad;
        //SendMessage(hlistaArchivos, LB_GETTEXT, w, (LPARAM) cadena2);
        if (origenestaendestino(cadena2, destino) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
/////////////////////////////////////////
BOOL destinoenorigenes3(TCHAR *destino, MiPathStr & salida)
{
    INT v;
    v = (INT) listaCarpetas.getPunterosCount();//SendMessage(hlistaCarpetas, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
	MiPathStr * mpst;
    for (int w = 0; w < v; w++)
    {
		mpst = (MiPathStr *) listaCarpetas.getPunteroAt(w);
		Miwcscpy(cadena2, *mpst);
        //SendMessage(hlistaCarpetas, LB_GETTEXT, w, (LPARAM) cadena2);
        if (origenestaendestino(cadena2, destino) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
/////////////////////////////////////////////
BOOL destinoenorigenes(TCHAR *destino, MiPathStr & salida)
{
    INT v;
	v = (INT) listaArchivos.getPunterosCount();// SendMessage(hlistaArchivos, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
	MiPathStr *pcad;
    for (int w = 0; w < v; w++)
    {
		pcad = (MiPathStr *)listaArchivos.getPunteroAt(w);
		cadena2 = *pcad;
        //SendMessage(hlistaArchivos, LB_GETTEXT, w, (LPARAM) cadena2);
        if (destinoestaenorigen(destino, cadena2) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
////////////////////////////////////////////////
BOOL destinosenorigen2(TCHAR *origen, MiPathStr & salida)
{
    INT v;
    v = (INT) listaDestinos.getPunterosCount();//SendMessage(hlistaDestinos, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
	MiPathStr *pcad;
    for (int w = 0; w < v; w++)
    {
        pcad = (MiPathStr *) listaDestinos.getPunteroAt(w);//SendMessage(hlistaDestinos, LB_GETTEXT, w, (LPARAM) cadena2);
        cadena2 = *pcad;
		if (origenestaendestino(origen, cadena2) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
////////////////////////////////////////////////
BOOL destinosenorigen3(TCHAR *origen, MiPathStr & salida)
{
    INT v;
    v = (INT) listaCarpetas.getPunterosCount();// SendMessage(hlistaCarpetas, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
	MiPathStr * mpst;
    for (int w = 0; w < v; w++)
    {
		mpst = (MiPathStr *) listaCarpetas.getPunteroAt(w);
		Miwcscpy(cadena2, *mpst);
        //SendMessage(hlistaCarpetas, LB_GETTEXT, w, (LPARAM) cadena2);
        if (origenestaendestino(origen, cadena2) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
////////////////////////////////////////////
BOOL destinosenorigen(TCHAR *origen, MiPathStr & salida)
{
    INT v;
    v = (INT) listaDestinos.getPunterosCount();//SendMessage(hlistaDestinos, LB_GETCOUNT, 0, 0);
    MiPathStr cadena2;
	MiPathStr *mp;
    for (int w = 0; w < v; w++)
    {
        mp = (MiPathStr *) listaDestinos.getPunteroAt(w);//)SendMessage(hlistaDestinos, LB_GETTEXT, w, (LPARAM) cadena2);
        Miwcscpy(cadena2, *mp);
		if (destinoestaenorigen(cadena2, origen) == TRUE)
        {
			salida = cadena2;
            //wcscpy_s(salida, MIMAXPATH, cadena2);
            return TRUE;
        }
    }
    return FALSE;
}
/////////////////////////////////////////
BOOL destinoestaenorigen(WCHAR *destino, WCHAR *origen)
{
    if (wcslen(origen) > wcslen(destino))
        return FALSE;
    if (wcslen(origen) == wcslen(destino))
    {
        if (_wcsicmp(origen, destino) != 0)
            return FALSE;
        else
            return TRUE;
    }
    INT x;
    x = (INT) wcslen(origen);
    if (_wcsnicmp(origen, destino, wcslen(origen)) != 0)
        return FALSE;
    if (wcslen(origen) < 4)
        return TRUE;
    if (destino[wcslen(origen)] != L'\\')
        return FALSE;
    return TRUE;
}
//////////////////////////////////////////////
BOOL origenestaendestino(WCHAR *origen, WCHAR *destino)
{
    UINT y;
	INT si = 0, h = 0;
    if (wcslen(origen) < wcslen(destino))
        return FALSE;
    if (wcslen(origen) == wcslen(destino))
    {
        if (_wcsicmp(origen, destino) != 0)
            return FALSE;
        else
            return TRUE;
    }
    INT x;
	if(destino[wcslen(destino) - 2] == L':')
		h = 1;
	x = (INT) wcslen(destino);
        for(y = (UINT) wcslen(destino) - h; y < (UINT) wcslen(origen); y++)
        {
                if(origen[y] == L'\\')
                        ++si;
        }
        if(si > 1)
                return FALSE;
    if (_wcsnicmp(origen, destino, wcslen(destino)) != 0)
        return FALSE;
    if (wcslen(destino) < 4)
        return TRUE;
	if (origen[wcslen(destino)] != L'\\')
		return FALSE;
    return TRUE;
}

/////////////////////////////////////////////////
void EscribirCantidadDeElementos(MiListaPunteros * mlp, HDC hdc, COLORREF colfondo, INT cx, INT cy)
{
    COLORREF coltexto, colfv, coltv;
    MiPathStr cadena(244);
    INT cont;
    cont = (INT) mlp->getPunterosCount();// SendMessage(hcontrol, LB_GETCOUNT, 0, 0);
    coltexto = RGB(255, 255, 255);
    EJECUTARSIRETORNOIG(SetTextColor(hdc, coltexto), CLR_INVALID, coltv);
    EJECUTARSIRETORNOIG(SetBkColor(hdc, colfondo), CLR_INVALID, colfv);
    swprintf(cadena, 244, TEXT("%d"), cont);
	MiPonerSeparadorMiles(cadena);
    EJECUTARNORETORNOIG(TextOut(hdc, cx + 5, cy, cadena, cadena.len()), 0);
    EJECUTARNORETORNOIG(SetTextColor(hdc, coltv), CLR_INVALID);
    EJECUTARNORETORNOIG(SetBkColor(hdc, colfv), CLR_INVALID);
}
/////////////////////////////////////////////////
void EscribirNumeroDeElementos(HWND  hcontrol, HDC hdc, COLORREF colfondo, INT cx, INT cy)
{
    COLORREF coltexto, colfv, coltv;
    MiPathStr cadena(244);
    INT cont;
    cont = (INT) SendMessage(hcontrol, LB_GETCOUNT, 0, 0);
    coltexto = RGB(255, 255, 255);
    EJECUTARSIRETORNOIG(SetTextColor(hdc, coltexto), CLR_INVALID, coltv);
    EJECUTARSIRETORNOIG(SetBkColor(hdc, colfondo), CLR_INVALID, colfv);
    swprintf(cadena, 244, TEXT("%d"), cont);
	MiPonerSeparadorMiles(cadena);
    EJECUTARNORETORNOIG(TextOut(hdc, cx + 5, cy, cadena, cadena.len()), 0);
    EJECUTARNORETORNOIG(SetTextColor(hdc, coltv), CLR_INVALID);
    EJECUTARNORETORNOIG(SetBkColor(hdc, colfv), CLR_INVALID);
}
////////////////////////////////////////////////////////
BOOL escorrectoparalistaorigenespuros(WCHAR * cadena, HWND hwnd)
{
	MiPathStr  * mpst = new MiPathStr();
	*mpst = cadena;
	if(listaArchivos.buscaPunteroNoOrdenado((funcionComparadoraMiListaPunteros) comparar,/*(funcionComparadoraMiListaPunteros) &comparar,*/ (void **)&mpst) != NULL)

    //if (SendMessage(hlistaArchivos, LB_FINDSTRINGEXACT, 0XFFFFFFFF, (LPARAM) cadena) != LB_ERR)
    {
        MessageBox(hwnd, cadena, TEXT(SZNOADDESTAENLISTA), MB_OK | MB_ICONINFORMATION);
        return FALSE;;
    }
    if (wcslen(cadena) < 4)
    {
        MessageBox(hwnd, cadena, TEXT(SZDISKDRIVE), MB_OK | MB_ICONINFORMATION);
        return FALSE;;
    }  
    MiPathStr cadena4(MIMAXPATH * 2);
    MiPathStr salida(MIMAXPATH * 2);
    if (destinosenorigen(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
        //wcscpy_s(cadena4, cadena4.dispo(), cadena);
        //wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        //wcscat_s(cadena4, cadena4.dispo(), salida);
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if (destinosenorigen2(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZESTACONTENIDOEN);
		cadena4 += salida;
		/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida); */
        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if (destinosenorigen3(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZESTACONTENIDOEN);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes2(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZESTACONTENIDOEN);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida); */
        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes3(cadena, salida) == TRUE)
    {
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    return TRUE;
}
/////////////////////////////////////////////////////////////////////
static BOOL escorrectoparalistaorigenescarpetas(WCHAR * cadena, HWND hwnd)
{
	//return TRUE;
	MiPathStr  * mpst = new MiPathStr();
	*mpst = cadena;
	if(listaCarpetas.buscaPunteroNoOrdenado((funcionComparadoraMiListaPunteros) comparar,/*(funcionComparadoraMiListaPunteros) &comparar, */(void **)&mpst) != NULL)
    //if (SendMessage(hlistaCarpetas, LB_FINDSTRINGEXACT, 0XFFFFFFFF, (LPARAM) cadena) != LB_ERR)
    {
        MessageBox(hwnd, cadena, TEXT(SZNOADDESTAENLISTA), MB_OK | MB_ICONINFORMATION);
        return FALSE;;
    }
	
    MiPathStr cadena4(MIMAXPATH * 2);
    MiPathStr salida(MIMAXPATH * 2);
    if (destinosenorigen(cadena, salida) == TRUE)
    {
		
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if (destinosenorigen3(cadena, salida) == TRUE)
    {
		//MessageBoxA(hwnd, "cucu2", "cucua", MB_OK);
		cadena4 = cadena;
		cadena4 += TEXT(SZESTACONTENIDOEN);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida);
		*/
        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes2(cadena, salida) == TRUE)
    {
		//MessageBoxA(hwnd, "cucu3", "cucua", MB_OK);
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(),  cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes(cadena, salida) == TRUE)
    {
		//MessageBoxA(hwnd, "cucu4", "cucua", MB_OK);
		cadena4 = cadena;
		cadena4 += TEXT(SZESTACONTENIDOEN);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
    if(destinoenorigenes3(cadena, salida) == TRUE)
    {
		//MessageBoxA(hwnd, "cucu5", "cucua", MB_OK);
		cadena4 = cadena;
		cadena4 += TEXT(SZCONTIENEA);
		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
        MessageBox(hwnd, cadena4, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return FALSE;
    }
	//listaCarpetas.ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
////    if (destinosenorigen2(cadena, salida) == TRUE)
////    {
////		if(wcscmp(cadena, salida))		
////			return TRUE;
		//MessageBoxA(hwnd, "cucu1", "cucua", MB_OK);
////		cadena4 = cadena;
////		cadena4 += TEXT(SZESTACONTENIDOEN);
////		cadena4 += salida;
/*
        wcscpy_s(cadena4, cadena4.dispo(), cadena);
        wcscat_s(cadena4, cadena4.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena4, cadena4.dispo(), salida);*/
////        MessageBox(hwnd, cadena4, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
////        return FALSE;
////    }

	return TRUE;
}
/////////////////////////////////////////////////////////////////////
static void aniadircontenidodedirectorio(WCHAR * cadena, IShellFolder **  fold, LPITEMIDLIST ** pil, INT *iii)
{
    WIN32_FIND_DATA  wfd;
    HANDLE hd;
    MiPathStr temporal;
    MiPathStr otro;
    BOOL bien;	
    temporal = cadena;
    temporal.bs();
    temporal += L"*";
    hd = FindFirstFileExHechaPorMi(temporal, FindExInfoStandard, &wfd, FindExSearchNameMatch, NULL, 0);
    if(hd != INVALID_HANDLE_VALUE)
        bien = TRUE;
    else
        bien = FALSE;
    while(bien == TRUE)
    {
        if((wfd.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM)||(wcscmp(wfd.cFileName, L".") == 0) || (wcscmp(wfd.cFileName, L"..") == 0))
        {
            bien = FindNextFile(hd, &wfd);
            continue;
        }
        otro = cadena;
        otro.bs();
        otro += wfd.cFileName;
        *pil = (LPITEMIDLIST *) Mirealloc((*pil), sizeof(LPITEMIDLIST) * (*iii));
		if((*fold)->ParseDisplayName(NULL, NULL, otro, NULL, &((*pil)[(*iii) - 1]), NULL) != S_OK)
                    MostrarError(TEXT(__FILE__), __LINE__);		
		++(*iii);
        bien = FindNextFile(hd, &wfd);
    }
    if(hd != INVALID_HANDLE_VALUE)
        FindClose(hd);
}
//////////////////////////////////////////////////////////////////////
void aniadirdirectoriodestino(WCHAR *cadena, HWND hwnd)
{
    DWORD finf;
	MiPathStr  * mpst = new MiPathStr();
	*mpst = cadena;
	if(listaDestinos.buscaPunteroNoOrdenado((funcionComparadoraMiListaPunteros) comparar,/*(funcionComparadoraMiListaPunteros) &comparar, */(void **)&mpst) != NULL)

    //if (SendMessage(hlistaDestinos, LB_FINDSTRINGEXACT, 0XFFFFFFFF, (LPARAM) cadena) != LB_ERR)
    {
        MessageBox(hwnd, cadena, TEXT(SZNOADDESTAENLISTA), MB_OK | MB_ICONINFORMATION);
        return;
    }
    finf = GetFileAttributesHechaPorMi(cadena);
    if (!(finf & FILE_ATTRIBUTE_DIRECTORY))
    {
        MessageBox(hwnd, cadena, TEXT(SZNODIRECTORIO), MB_OK | MB_ICONINFORMATION);
        return;
    }
    MiPathStr mirollo, mirollo2;
    FILE * mirio;
    BOOL guay = TRUE;
    INT cucu = 1;
    while (guay == TRUE)
    {
        mirollo = cadena;
        mirollo.bs();
        swprintf(mirollo2, mirollo2.dispo(), L"__%d", cucu);
        ++cucu;
        mirollo += mirollo2;
        mirio = _wfopen(mirollo, TEXT("r"));
        if (mirio != NULL)
        {
            guay = TRUE;
            fclose(mirio);
        }
        else
            guay = FALSE;
    }
    if ((mirio = _wfopen(mirollo, L"wb")) == NULL)
    {
        MessageBox(hwnd, cadena, TEXT(SZNOCANESCRIBIR), MB_OK |MB_ICONINFORMATION);
        return;
    }
    fclose(mirio);
    EJECUTARNORETORNOIG(DeleteFile(mirollo), 0);
    MiPathStr salida;
    if (destinoenorigenes(cadena, salida) == TRUE)
    {
        MiPathStr cadena3(MIMAXPATH * 2);
		cadena3 = cadena;
		cadena3 += TEXT(SZESTACONTENIDOEN);
		cadena3 += salida;
/*
        wcscpy_s(cadena3, cadena3.dispo(), cadena);
        wcscat_s(cadena3, cadena3.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena3, cadena3.dispo(),  salida);*/
        MessageBox(hwnd, cadena3, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return;
    }
    if (destinoenorigenes2(cadena, salida) == TRUE)
    {
        MiPathStr cadena3(MIMAXPATH * 2);
		cadena3 = cadena;
		cadena3 += TEXT(SZCONTIENEA);
		cadena3 += salida;
/*
        wcscpy_s(cadena3, cadena3.dispo(), cadena);
        wcscat_s(cadena3, cadena3.dispo(), TEXT(SZCONTIENEA));
        wcscat_s(cadena3, cadena3.dispo(), salida);*/
        MessageBox(hwnd, cadena3, TEXT(SZPRIMCONTSEG), MB_OK | MB_ICONINFORMATION);
        return;
    }
    if (destinosenorigen3(cadena, salida) == TRUE)
    {
        MiPathStr cadena3(MIMAXPATH * 2);
		cadena3 = cadena;
		cadena3 += TEXT(SZESTACONTENIDOEN);
		cadena3 += salida;
/*
		wcscpy_s(cadena3, cadena3.dispo(), cadena);
        wcscat_s(cadena3, cadena3.dispo(), TEXT(SZESTACONTENIDOEN));
        wcscat_s(cadena3, cadena3.dispo(), salida);*/
        MessageBox(hwnd, cadena3, TEXT(SZCONTENIDOENSEGUNDO), MB_OK | MB_ICONINFORMATION);
        return;
    }
	MiPathStr * mpstr = new MiPathStr();
	Miwcscpy(*mpstr, cadena);
	listaDestinos.aniadirPuntero(mpstr);
    //SendMessage(hlistaDestinos, LB_ADDSTRING, 0, (LPARAM) cadena);
}
//////////////////////////////////////////////////////////////////
static void maMostrarMenuContextual(HWND hwnd, INT cox, INT coy)
{
    BOOL valor;
    MiPathStr cadena;
    HMENU hmenu;
    INT resul;
    MENUITEMINFO mii;
    EJECUTARSIRETORNOIG(CreatePopupMenu(), NULL, hmenu);
    ZeroMemory(&mii, sizeof(MENUITEMINFO));
    mii.cbSize = sizeof(MENUITEMINFO);
    mii.fMask = MIIM_ID | MIIM_STRING | MIIM_STATE;
    mii.fType = MFT_RADIOCHECK;
    valor = cdgetRadio3();
    if(valor == TRUE)
        mii.fState = MFS_ENABLED | MFS_CHECKED;
    else
        mii.fState = MFS_ENABLED | MFS_UNCHECKED;
    mii.wID = MENUCOPIAR;
    mii.dwTypeData = SZCOPY;
    mii.cch = (UINT) wcslen(SZCOPY);
    InsertMenuItem(hmenu, MENUMOVER, FALSE, &mii);
    if(valor == FALSE)
        mii.fState = MFS_ENABLED | MFS_CHECKED;
    else
        mii.fState = MFS_ENABLED | MFS_UNCHECKED;
    mii.wID = MENUMOVER;
    mii.dwTypeData = SZMOVE;
    mii.cch = (UINT) wcslen(SZMOVE);
    InsertMenuItem(hmenu, MENUANIADIRDIRECTORIOORIGEN, FALSE, &mii);
    mii.fMask = MIIM_FTYPE;
    mii.fType = MFT_SEPARATOR;
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUANIADIRFICHEROSORIGENES, FALSE, &mii), 0);
    mii.fMask = MIIM_ID | MIIM_STRING | MIIM_STATE;
    mii.fState = MFS_ENABLED;
    mii.wID = MENUANIADIRFICHEROSORIGENES;
    mii.dwTypeData = TEXT(SZANIADIRORIGENES);
    mii.cch = (UINT) wcslen(TEXT(SZANIADIRORIGENES));
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUANIADIRDIRECTORIOORIGEN, FALSE, &mii), 0);
    mii.wID = MENUANIADIRDIRECTORIOORIGEN;
    mii.dwTypeData = TEXT(SZANIADIRCARPETAORIGEN);
    mii.cch = (UINT) wcslen(TEXT(SZANIADIRCARPETAORIGEN));
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUANIADIRCONTENIDOORIGEN, FALSE, &mii), 0);
    mii.wID = MENUANIADIRCONTENIDOORIGEN;
    mii.dwTypeData = TEXT(SZANIADIRCONTENIDOCARPETAORIGEN);
    mii.cch = (UINT) wcslen(TEXT(SZANIADIRCONTENIDOCARPETAORIGEN));
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUANIADIRDESTINO, FALSE, &mii), 0);
    mii.wID = MENUANIADIRDESTINO;
    mii.dwTypeData = TEXT(SZANIADIRCARPETADESTINO);
    mii.cch = (UINT) wcslen(TEXT(SZANIADIRCARPETADESTINO));
    InsertMenuItem(hmenu, MENUSALIR, FALSE, &mii);
    mii.fMask = MIIM_FTYPE;
    mii.fType = MFT_SEPARATOR;
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUSALIR, FALSE, &mii), 0);
    
	mii.fState = MFS_ENABLED;
    mii.fMask = MIIM_ID | MIIM_STRING | MIIM_STATE;
    mii.wID = MENUSALIR;
    mii.dwTypeData = TEXT(SZQUIT);
    mii.cch = (UINT) wcslen(TEXT(SZQUIT));
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUSALIR, FALSE, &mii), 0);

	mii.fState = MFS_ENABLED;
    mii.fMask = MIIM_ID | MIIM_STRING | MIIM_STATE;
    mii.wID = MENUABOUT;
    mii.dwTypeData = SZABOUT;
    mii.cch = (UINT) wcslen(SZABOUT);
    EJECUTARNORETORNOIG(InsertMenuItem(hmenu, MENUABOUT, FALSE, &mii), 0);


	
	resul = TrackPopupMenu(hmenu, TPM_RETURNCMD | TPM_LEFTBUTTON, cox, coy, 0, hwnd, NULL);
    if(resul == MENUSALIR)
        DestroyWindow(hwnd);
    else if (resul == MENUANIADIRDESTINO)
    {
        if(maExaminarDirectorio(cadena, hwnd) == TRUE)
        {
            aniadirdirectoriodestino(cadena, hwnd);
            EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
        }
    }
    else if (resul == MENUANIADIRCONTENIDOORIGEN)
    {
        if(maExaminarDirectorio(cadena, hwnd) == TRUE)
        {
			if(escorrectoparalistaorigenescarpetas(cadena, hwnd) == TRUE)
			{
				MiPathStr * mpst = new MiPathStr();
				*mpst = cadena;
				listaCarpetas.aniadirPuntero(mpst);
			}
			//	SendMessage(hlistaCarpetas, LB_ADDSTRING, 0, (LPARAM) cadena);
            EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
        }
    }
    else if (resul == MENUANIADIRFICHEROSORIGENES)
    {
        AnnadirFilesALista(hwnd);
        EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
    }
    else if (resul == MENUANIADIRDIRECTORIOORIGEN)
    {
        if(maExaminarDirectorio(cadena, hwnd) == TRUE)
        {
            if (escorrectoparalistaorigenespuros(cadena, hwnd) == TRUE)
            {
				MiPathStr * cad = new MiPathStr();
				Miwcscpy(*cad, cadena);
				//cad = cadena;
				listaArchivos.aniadirPuntero(cad);
                //SendMessage(hlistaArchivos, LB_ADDSTRING, 0, (LPARAM) cadena);
            }
        }
        EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
    }
    else if (resul == MENUCOPIAR)
    {
        cdsetEstado(TRUE, FALSE);
        EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
    }
    else if (resul == MENUMOVER)
    {
        cdsetEstado(FALSE, TRUE);
        EJECUTARNORETORNOIG(InvalidateRect(hwnd, NULL, TRUE), 0);
    }
    else if (resul == MENUABOUT)
    {
		JoseAbout(hwnd, L"n2ncopy", TEXTOVERSION);
    }
	
    EJECUTARNORETORNOIG(DestroyMenu(hmenu), 0);
}
/////////////////////////////////////////////////////////////////////
static BOOL maExaminarDirectorio(MiPathStr & directorioexaminado, HWND hventmadre)
{
    BROWSEINFO bi;
    MiPathStr cadena;
    LPITEMIDLIST lpiil;
    ZeroMemory(&bi, sizeof(BROWSEINFO));
    bi.hwndOwner = hventmadre;
    bi.pszDisplayName = cadena;
    bi.ulFlags = BIF_RETURNONLYFSDIRS;
    if((lpiil = SHBrowseForFolder(&bi)) == NULL)
        return FALSE;
    if(SHGetPathFromIDList(lpiil, cadena) == TRUE)
    {
		directorioexaminado = cadena;
        CoTaskMemFree(lpiil);
        return TRUE;
    }
    CoTaskMemFree(lpiil);
    return FALSE;
}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
static TCHAR * fichs;
//////////////////////////////////////////////////////////////////////////////
static void AnnadirFilesALista(HWND hwnd)//, UINT listaid, UINT otralistaid)
{
    OPENFILENAME ofn;
    INT pos = 0;
    MiPathStr ruta(MAX_PATH * 2);
    MiPathStr completo(MAX_PATH * 2);
    fichs = (WCHAR *) Mimalloc(sizeof(WCHAR) * 8);
    fichs[0] = L'\0';
    ZeroMemory(&ofn, sizeof(OPENFILENAME));
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = hwnd;
    #ifdef CASTELLANO
    ofn.lpstrFilter = TEXT("Todos los ficheros\0*.*\0\0");
    #endif
    #ifdef ENGLISH
    ofn.lpstrFilter = TEXT("All files\0*.*\0\0");
    #endif
    ofn.lpstrFile = fichs;
    ofn.nMaxFile = 3;
    ofn.lpfnHook = MiOFNHookProc;
    ofn.Flags = OFN_ALLOWMULTISELECT | OFN_EXPLORER | OFN_ENABLEHOOK  |
                OFN_DONTADDTORECENT |
                OFN_NODEREFERENCELINKS | OFN_NONETWORKBUTTON;
    if(GetOpenFileName(&ofn) == FALSE)
    {
        {
            free(fichs);
            return;
        }
    }
    ruta = &fichs[pos];
	ruta.pref();
    if(!(GetFileAttributes(ruta) & FILE_ATTRIBUTE_DIRECTORY))
    {
        if (escorrectoparalistaorigenespuros(MiSinPref(ruta), hwnd) == TRUE)
        {
			MiPathStr * cad = new MiPathStr();
			Miwcscpy(*cad, MiSinPref(ruta));
			listaArchivos.aniadirPuntero(cad);

            //SendMessage(hlistaArchivos, LB_ADDSTRING, 0, (LPARAM) MiSinPref(ruta));
        }
        free(fichs);
        return;
    }
    ruta.bs();
    while(fichs[pos] != L'\0')
        ++pos;
    ++pos;
    while(fichs[pos] != L'\0')
    {
		completo = ruta;
		completo += &fichs[pos];
        //wcscpy_s(completo, completo.dispo(), ruta);
        //wcscat_s(completo, completo.dispo(), &fichs[pos]);
        if(GetFileAttributes(completo) != INVALID_FILE_ATTRIBUTES)
        {
            if (escorrectoparalistaorigenespuros(MiSinPref(completo), hwnd) == TRUE)
            {
				MiPathStr * cad = new MiPathStr();
				Miwcscpy(*cad, MiSinPref(completo));
				listaArchivos.aniadirPuntero(cad);
                //SendMessage(hlistaArchivos, LB_ADDSTRING, 0, (LPARAM) MiSinPref(completo));
            }
        }
        while(fichs[pos] != L'\0')
            ++pos;
        ++pos;
    }
    free(fichs);
    return;
}
/////////////////////////////////////////////////////////////////
UINT_PTR CALLBACK MiOFNHookProc(HWND hdlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
    NMHDR *phd;
    OFNOTIFY * pon;
    UINT cucu;
    TCHAR buf[4];
    OPENFILENAME * ofn;
    if(uiMsg != WM_NOTIFY)
    {
        return 0;
    }
    phd = (NMHDR *) lParam;
    if(phd->code != CDN_SELCHANGE)
    {
           return 0;
    }
    pon = (OFNOTIFY *) lParam;
    cucu = (UINT) SendMessage(GetParent(hdlg), CDM_GETSPEC, 2, (LPARAM) buf);
    fichs = (TCHAR *) Mirealloc(fichs, (MIMAXPATH * sizeof(TCHAR)) + (sizeof(TCHAR) * cucu) + 44 );
    ofn = (OPENFILENAME *) pon->lpOFN;
    ofn->lpstrFile = fichs;
    ofn->nMaxFile = (MIMAXPATH) + cucu + 22;
    return 0;
}
