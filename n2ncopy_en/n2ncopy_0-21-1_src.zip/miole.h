#ifndef OLEARBOLGRANDE_H_INCLUDED
#define OLEARBOLGRANDE_H_INCLUDED

#include "cabecera.h"
#include "shlobj.h"


/////////////////////////////////////////////////////
class CIDropSource : public IDropSource
{
    public:
        HRESULT __stdcall QueryInterface(REFIID iid, void ** ppvObject);
        ULONG __stdcall AddRef(void);
        ULONG __stdcall Release(void);
        HRESULT __stdcall QueryContinueDrag(BOOL fEscapePressed, DWORD grfKeyState);
        HRESULT __stdcall GiveFeedback(DWORD dwEffect);
        CIDropSource()
        {
            m_nRef = 0;
        }
    private:
        LONG m_nRef;
};
///////////////////////////////////////////////////////////
class CIDropTarget : public IDropTarget
{
public:
    HRESULT __stdcall QueryInterface (REFIID iid, void ** ppvObject);
    ULONG   __stdcall AddRef (void);
    ULONG   __stdcall Release (void);

	HRESULT __stdcall DragEnter(IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect);
	HRESULT __stdcall DragOver(DWORD grfKeyState, POINTL pt, DWORD * pdwEffect);
	HRESULT __stdcall DragLeave(void);
	HRESULT __stdcall Drop(IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect);

	CIDropTarget(HWND hwnd)
	{
		nRef = 0;
		hw = hwnd;
	};

private:
	DWORD DropEffect(DWORD grfKeyState, POINTL pt, DWORD dwAllowed);
	bool QueryDataObject(IDataObject *pDataObject);

	long nRef;
	HWND hw;
	bool fAllowDrop;
};



#endif // OLEARBOLGRANDE_H_INCLUDED

