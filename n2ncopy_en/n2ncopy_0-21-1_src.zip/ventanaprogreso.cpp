#include "cabecera.h"

DWORD WINAPI funcionsubproceso(LPVOID lpParameter);
INT_PTR CALLBACK ProgDialogProc(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam);

static LPDATOSDECOPIA datos;
static HANDLE evento;
static HANDLE subproceso;
static SUBPROCDATA datossp;
//static DWORD estatus;

BOOL iniciarVentanaProgreso(LPDATOSDECOPIA dat, HWND hwnd)
{
    BOOL ret;
    datos = dat;

    ret = (BOOL) DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG2), hwnd, ProgDialogProc);
    CloseHandle(subproceso);
    CloseHandle(evento);
    return ret;
}
///////////////////////////////////////////////////////////////////////
INT_PTR ProgDialogProcViejo(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam)
{
	
//    DWORD estatus;
    switch(mensaje)
    {
        case WM_TIMER:
        {
            DWORD cucu;
            GetExitCodeThread(subproceso, &cucu);
            if(cucu != STILL_ACTIVE)
            //if(WaitForSingleObject(evento, 0) == WAIT_OBJECT_0)
            {
                KillTimer(hwnd, TEMPORIZADOR);
                //GetExitCodeThread(subproceso, &estatus);
                EndDialog(hwnd, TRUE);
            }
            return TRUE;
        }
        case WM_INITDIALOG:
        {
            SetTimer(hwnd, TEMPORIZADOR, 1000, (TIMERPROC) NULL);
            datossp.pdatoscopia = datos;
            evento = CreateEvent(NULL, TRUE, FALSE, NULL);
            datossp.evento = evento;
            //datossp.larg = ID_TEXTOELEMENTO;
            //datossp.cort = ID_TEXTOACCION;
            datossp.ventana = hwnd;
            subproceso = CreateThread(NULL, 0, funcionsubproceso, &datossp,
                                     0, NULL);
            return TRUE;
        }
        case WM_COMMAND:
        {
            if(LOWORD(wParam) == IDBOTONCANCELAR)
            {
                DWORD vret;
                KillTimer(hwnd, TEMPORIZADOR);
                SetEvent(evento);
                vret = STILL_ACTIVE;
                while(vret == STILL_ACTIVE)
                {
                    Sleep(70);
                    GetExitCodeThread(subproceso, &vret);
                }
                //SignalObjectAndWait(evento, subproceso, INFINITE, FALSE);
                //WaitForSingleObject(subproceso, INFINITE);

                EndDialog(hwnd, FALSE);
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        default:
        {
          PARNOUSADO(lParam);
            return FALSE;
        }
    }
//    return FALSE;
}
///////////////////////////////////////////////////////////
INT_PTR vpOnAccion(HWND hw, WPARAM wp, LPARAM lp)
{
	SetDlgItemText(hw, ID_TEXTOACCION, (WCHAR *) wp);
	GlobalFree((WCHAR *) wp);
	SetDlgItemText(hw, ID_TEXTOELEMENTO, (WCHAR *) lp);
	GlobalFree((WCHAR *) lp);
	return 0;
}
///////////////////////////////////////////////////////////
INT_PTR CALLBACK ProgDialogProc(HWND hw, UINT mens, WPARAM wp, LPARAM lp)
{	
	PROCESARMENSAJE(mens, WM_ACCION, vpOnAccion, hw, wp, lp);
	return(ProgDialogProcViejo(hw, mens, wp, lp));
}