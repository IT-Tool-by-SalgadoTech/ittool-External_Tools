#include "cabecera.h"
 
int comparar(void * p1, void * p2);
void edBorrarContenidoDestinos(LPSUBPROCDATA lpspd);

#define TAMANIOBUFFER (8 * 1024 * 1024)
#define DESTINOSCOPIA 100

static BOOL nosehacopiado;

void edborrarelemento(TCHAR elemento[]);
void edmoverelemento(TCHAR elemento[], TCHAR target[], BOOL overwrite, 
					 HWND hventana, BOOL nohacernada, BOOL *nosehacopiado);

void MostrarError(TCHAR *ficheroerror, INT lineaerror);

static void hacerTareaConInteriorDeCarpeta(MiPathStr * cadena);
static LPSUBPROCDATA lpspd;
static MiPathStr * destinoscopia;
static MiPathStr destinomover;
static BOOL semueve;
static INT numdestinoscopia;

void copiaradestinos(MiPathStr * elemento);
void dotareaconunelem(MiPathStr *elemento);
void copiaranumerodestinos(MiPathStr destinos[],
                        INT numdestinos,
                        MiPathStr * elemento);
void copiararchivo(MiPathStr destinos[],
                    INT numdestinos,
                    MiPathStr * elemento);
void copiardirectorio(MiPathStr destinos[],
                        INT numdestinos,
                        MiPathStr * elemento);
void renombrarsiexistearchivo(MiPathStr * ruta);
void copiaravariosarchivos(MiPathStr destinoparticular[], INT numdestinos, MiPathStr * elemento);
void renombrarsiexistedir(MiPathStr * dir);
void copiarvariosdirectorios(MiPathStr dirs[], INT numdirs, MiPathStr * direct);
//////////////////////////////////////////////////////
void suIndicar(WCHAR * accion, MiPathStr *item, HWND hw)
{
	WCHAR * cadenawa = (WCHAR *) GlobalAlloc(GMEM_FIXED, (wcslen(accion) + 1) * sizeof(WCHAR));
	Miwcscpy(cadenawa, accion);
	WCHAR * cadenawb = (WCHAR *) GlobalAlloc(GMEM_FIXED, (wcslen(*item) + 1) * sizeof(WCHAR));
	Miwcscpy(cadenawb, *item);
	PostMessage(hw, WM_ACCION, (WPARAM) cadenawa, (LPARAM) cadenawb); 
}
//////////////////////////////////////////////////////
DWORD WINAPI funcionsubproceso(LPVOID lpParameter)
{
    INT i;
    lpspd = (LPSUBPROCDATA) lpParameter;
	//Ordeno las listas en orden alfabetico
	lpspd->pdatoscopia->listaArchivos->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
	lpspd->pdatoscopia->listacarpetas->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
	lpspd->pdatoscopia->listadestinos->ordenarPunteros((funcionComparadoraMiListaPunteros) comparar);
	//Borro el contenido de los destino si asi lo
	//ha indicado el usuario
	edBorrarContenidoDestinos(lpspd);
	//Copio los elementos que se han de copiar
    for(i = 0; i < lpspd->pdatoscopia->numdatos; i++)
    {
		dotareaconunelem((MiPathStr	*)lpspd->pdatoscopia->listaArchivos->getPunteroAt(i));
        if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
            return FALSE;
    }
	//Copio solo el contenido de los elementos cuyo contenido se ha de copiar
	for(i = 0; i < lpspd->pdatoscopia->numcarpetas; i++)
	{
		hacerTareaConInteriorDeCarpeta((MiPathStr *) lpspd->pdatoscopia->listacarpetas->getPunteroAt(i));
		if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
			return FALSE;
	}
    return TRUE;
}
/////////////////////////////////////////////////////
static void hacerTareaConInteriorDeCarpeta(MiPathStr * cadena)
//  Copia el interior de  las carpetas elegidas
//  para copiar solo el interior.
{
    WIN32_FIND_DATA  wfd;
    HANDLE hd;
    MiPathStr temporal;
    BOOL bien;
    Miwcscpypref(temporal, *cadena);
    MiPathAddBackSlash(temporal);
    Miwcscat(temporal, L"*");
    EJECUTARSIRETORNOIG(FindFirstFileEx(temporal, FindExInfoStandard, &wfd, FindExSearchNameMatch, NULL, 0), 
        INVALID_HANDLE_VALUE, hd);
    bien = TRUE;
    while(bien == TRUE)
    {
        if((wfd.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM)||
           (wcscmp(wfd.cFileName, L".") == 0) ||
           (wcscmp(wfd.cFileName, L"..") == 0))
        {
            bien = FindNextFile(hd, &wfd);
            continue;
        }
        Miwcscpy(temporal, *cadena);
        MiPathAddBackSlash(temporal);
        Miwcscat(temporal, wfd.cFileName);
		dotareaconunelem(&temporal);
        bien = FindNextFile(hd, &wfd);
    }
    EJECUTARNORETORNODI(GetLastError(), ERROR_NO_MORE_FILES);
    EJECUTARNORETORNOIG(FindClose(hd), FALSE);
}
//////////////////////////////////////
void indicarcopiando(MiPathStr * actual)
{
	suIndicar(SZCOPIANDO, actual, lpspd->ventana);
}
////////////////////////////////////////////
void dotareaconunelem(MiPathStr *elemento)
{
    nosehacopiado = FALSE;
    MiPathStr volumenelem, volumenitem;
    INT h = 0;
	UINT i;
    BOOL hecho = FALSE, ciclo;
    semueve = FALSE;
    if(!MiExisteElemento(*elemento))
        return;
    destinoscopia = new MiPathStr[lpspd->pdatoscopia->numdestinos];
    if(destinoscopia == 0)
        MostrarError(TEXT(__FILE__), __LINE__);
    Miwcscpy(volumenelem, *elemento);
    volumenelem[3] = L'\0';
	MiListaPunteros * auxbuc;
	UINT auxBucInt;
	auxbuc = lpspd->pdatoscopia->listadestinos;
	auxBucInt = auxbuc->getPunterosCount();
    for(i = 0; i < auxBucInt; i++)
    {
        ciclo = FALSE;
        Miwcscpy(volumenitem, *((MiPathStr *)(auxbuc->getPunteroAt(i))));
        volumenitem[3] = TEXT('\0');
		if((wcscmp(volumenitem, volumenelem) == 0) && (volumenitem[1] == L':'))
        {
            if((lpspd->pdatoscopia->mover == TRUE) && (hecho == FALSE))
            {
                Miwcscpy(destinomover, *((MiPathStr *) auxbuc->getPunteroAt(i)));
                hecho = TRUE;
                ciclo = TRUE;
                semueve = TRUE;
            }
        }
        if (ciclo == FALSE)
        {
            Miwcscpy(destinoscopia[h], *((MiPathStr *) auxbuc->getPunteroAt(i)));
			++h;
        }
    }
    if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
    {
		delete [] destinoscopia;
        return;
    }
    numdestinoscopia = h;
    if(h > 0)
        copiaradestinos(elemento);
    if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
    {
		delete [] destinoscopia;
        return;
    }
    if(lpspd->pdatoscopia->mover == TRUE)
    {
        if(semueve == TRUE)
        {
			edmoverelemento(*elemento, destinomover, lpspd->pdatoscopia->sobreescribir,
				lpspd->ventana, lpspd->pdatoscopia->nohacernada, &nosehacopiado);
        }
        else
        {
			if(nosehacopiado == FALSE)
				edborrarelemento(*elemento);
        }
    }
	delete [] destinoscopia;
}
/////////////////////////////////////////////////////////
void copiaradestinos(MiPathStr * elemento)
{
    //Falta copiar.
    INT i, j;
    for(i = 0; i < numdestinoscopia; i += DESTINOSCOPIA)
    {
        j = DESTINOSCOPIA;
        if(j > (numdestinoscopia  - i))
            j = numdestinoscopia - i;
        copiaranumerodestinos(&destinoscopia[i], j, elemento);
        //MessageBox(NULL, destinoscopia[i], TEXT("Copiar"), MB_OK);
        if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
        {
            return;
        }
    } 
}
//////////////////////////////////////////////
void copiaranumerodestinos(MiPathStr destinos[],
                        INT numdestinos,
                        MiPathStr * elemento)
{
    if (MiEsCarpeta(*elemento))
        copiardirectorio(destinos, numdestinos, elemento);
    else
        copiararchivo(destinos, numdestinos, elemento);
}
//////////////////////////////////////////
void copiardirectorio(MiPathStr destinos[],
                        INT numdestinos,
                        MiPathStr * elemento)
{
    //nosehacopiado = FALSE;
    indicarcopiando(elemento);
    MiPathStr dpartdir[DESTINOSCOPIA];
    MiPathStr solonombre;
    int i;
    HANDLE hhh;
    FILETIME creac, mod, acc;
    DWORD atrib;
    Miwcscpy(solonombre, *elemento);
    PathStripPathHechaPorMi(solonombre);
    for(i = 0; i < numdestinos; i++)
    {
		if(wcslen(destinos[i]) == 0)
		{
			nosehacopiado = TRUE;
			Miwcscpy(dpartdir[i], L"");
			continue;
		}
        Miwcscpy(dpartdir[i], destinos[i]);
        PathAddBackslashHechaPorMi(dpartdir[i]);
        Miwcscat(dpartdir[i], solonombre);
		if(lpspd->pdatoscopia->nohacernada == TRUE)
		{
			if(MiExisteElemento((WCHAR *)(MiPathStr)dpartdir[i]) == TRUE)
			{
				nosehacopiado = TRUE;
				Miwcscpy(dpartdir[i], L"");
			}
		}
        else if(lpspd->pdatoscopia->sobreescribir == FALSE)
        {
            renombrarsiexistedir(&dpartdir[i]);
        }
    } 
    copiarvariosdirectorios(dpartdir, numdestinos, elemento);
    hhh = CreateFileHechaPorMi(*elemento, GENERIC_READ, FILE_SHARE_READ,
                        NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
 //   if(hhh == INVALID_HANDLE_VALUE)
   //     MessageBeep(0xffffffff);
    GetFileTime(hhh, &creac, &mod, &acc);
    CloseHandle(hhh);
    atrib = GetFileAttributesHechaPorMi(*elemento);
    for(i = 0; i < numdestinos; i++)
    {
		if(wcslen(dpartdir[i]) == 0)
			continue;
     //   CreateDirectoryHechaPorMi(dirs[i], NULL);
        hhh = CreateFileHechaPorMi(dpartdir[i], GENERIC_WRITE, FILE_SHARE_WRITE,
                        NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
       // if(hhh == INVALID_HANDLE_VALUE)
        //{
            //MessageBox(NULL, dpartdir[i], dpartdir[i], MB_OK);
          //  MessageBeep(0xffffffff);
       // }
        SetFileTime(hhh, &creac, &mod, &acc);
        CloseHandle(hhh);
        SetFileAttributes(dpartdir[i], atrib);
    }


    //MessageBox(NULL, elemento, TEXT("Copiar directorio."), MB_OK);
}
////////////////////////////////////////////////
void copiarvariosdirectorios(MiPathStr dirs[], INT numdirs, MiPathStr * direct)
{
    INT i;
    MiPathStr ds[DESTINOSCOPIA];
    MiPathStr  temp, otro;
    WIN32_FIND_DATA  wfd;
    HANDLE hd;
    BOOL bien, copio;
	copio = TRUE;

    for(i = 0; i < numdirs; i++)
    {
		if(wcslen(dirs[i]) == 0)
			continue;
        if(CreateDirectoryHechaPorMi(dirs[i], NULL) == FALSE)
            MostrarError(TEXT(__FILE__), __LINE__);
 //       hhh = CreateFileHechaPorMi(dirs[i], GENERIC_READ | GENERIC_WRITE, 0,
   //                     NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
   //     SetFileTime(hhh, &creac, &mod, &acc);
     //   CloseHandle(hhh);
    }  
    Miwcscpy(temp, *direct);
    //_tcscpy(otro, direct);
    PathAddBackslashHechaPorMi(temp);
    Miwcscat(temp, TEXT("*"));
    hd = FindFirstFileExHechaPorMi(temp, FindExInfoStandard, &wfd, FindExSearchNameMatch, NULL, 0);
    //hd = FindFirstFile(temp, &wfd);
    if(hd != INVALID_HANDLE_VALUE)
        bien = TRUE;
    else
        bien = FALSE;
    while(bien == TRUE)
    {
        if((wcscmp(wfd.cFileName, TEXT(".")) == 0) || (wcscmp(wfd.cFileName, TEXT("..")) == 0))
        {
            bien = FindNextFile(hd, &wfd);
            continue;
        }
        for(i = 0; i< numdirs; i++)
        {
            Miwcscpy(ds[i], dirs[i]);
         //   PathAddBackslashHechaPorMi(ds[i]);
         //   _tcscat(ds[i], wfd->cFileName);

        }
        Miwcscpy(otro, *direct);
        PathAddBackslashHechaPorMi(otro);
        Miwcscat(otro, wfd.cFileName);
		
        if(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            copiardirectorio(ds, numdirs, &otro);
        }
        else
        {
            copiararchivo(ds, numdirs, &otro);
        }
        bien = FindNextFile(hd, &wfd);
        if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
        {
            FindClose(hd);
            return;
        }
    }
    if(hd != INVALID_HANDLE_VALUE)
        FindClose(hd);


}
///////////////////////////////////////////////
void renombrarsiexistedir(MiPathStr *dir)
{
    MiPathStr d;
    INT i = 1;
    Miwcscpy(d, *dir);
    while(PathFileExistsHechaPorMi(d) == TRUE)
    {
        wsprintf(d, L"%s_%d", (WCHAR *) *dir, i);
        i++;
    }
    Miwcscpy(*dir, d);
}
/////////////////////////////////////////////
void copiararchivo(MiPathStr destinos[],
                    INT numdestinos,
                    MiPathStr *elemento)
{
   // nosehacopiado = FALSE;
    //MessageBox(NULL, elemento, elemento, MB_OK);
    indicarcopiando(elemento);
    MiPathStr destinoparticular[DESTINOSCOPIA];
    MiPathStr solonombre;
    INT i; 
    Miwcscpy(solonombre, *elemento);
    PathStripPathHechaPorMi(solonombre);
    for(i = 0; i < numdestinos; i++)
    {
		if(wcslen(destinos[i]) == 0)
		{
			nosehacopiado = TRUE;
			Miwcscpy(destinoparticular[i], L"");
			continue;
		}
		//MessageBox(NULL, destinos[i], *elemento,  MB_OK);
        Miwcscpy(destinoparticular[i], destinos[i]);
        PathAddBackslashHechaPorMi(destinoparticular[i]);
        Miwcscat(destinoparticular[i], solonombre);
        if((lpspd->pdatoscopia->nohacernada == TRUE) && (MiExisteElemento(destinoparticular[i]) == TRUE))
		{
			//MessageBox(NULL, destinoparticular[i], solonombre, MB_OK);
			nosehacopiado = TRUE;
			Miwcscpy(destinoparticular[i], L"");
		}
		else if(lpspd->pdatoscopia->sobreescribir == FALSE)
        {
            renombrarsiexistearchivo(&destinoparticular[i]);
        }

    }
    
    copiaravariosarchivos(destinoparticular, numdestinos, elemento);
}
///////////////////////////////////////////////////
void renombrarsiexistearchivo(MiPathStr * ruta)
{
    TCHAR * extension;
    MiPathStr nombre;
    MiPathStr rutabb;
    //RUTAARCHIVO otro;
    INT i = 1;
    Miwcscpy(rutabb, *ruta);
    while(PathFileExistsHechaPorMi(rutabb) == TRUE)
    {
        Miwcscpy(rutabb, *ruta);
        extension = PathFindExtension(rutabb);
        Miwcscpy(nombre, extension);
        wsprintf(extension, TEXT("_%d"), i);
        Miwcscat(rutabb, nombre);
        i++;
    }
    Miwcscpy(*ruta, rutabb);
}
///////////////////////////////////////////////////////
void copiaravariosarchivos(MiPathStr destinoparticular[], INT numdestinos, MiPathStr * elemento)
{
    INT i;
    HANDLE destinos[DESTINOSCOPIA];
	BOOL esvacio[DESTINOSCOPIA];
	DWORD cantvacios = 0;
    HANDLE origen;
    BOOL acabado = FALSE, resultado;
    UCHAR * bufferparadatos;
    DWORD bytleidos, bytescritos;
    FILETIME creac, mod , acc;
    DWORD atrib, atribvie;
	ZeroMemory(esvacio, sizeof (BOOL) * DESTINOSCOPIA);
    bufferparadatos = (UCHAR *) malloc(sizeof(UCHAR) * TAMANIOBUFFER);
    atribvie = atrib = GetFileAttributesHechaPorMi(*elemento);
	MiSetFileAttributes(*elemento, FILE_ATTRIBUTE_NORMAL);

    origen = CreateFileHechaPorMi(*elemento, GENERIC_READ, FILE_SHARE_READ,
                        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(origen == INVALID_HANDLE_VALUE)
	{
		MiSetFileAttributes(*elemento, atrib);
        MostrarError(TEXT(__FILE__), __LINE__);
	}
    for(i = 0; i < numdestinos; i++)
    {
		if(wcslen(destinoparticular[i]) == 0)
		{
			nosehacopiado = TRUE;
			esvacio[i] = TRUE;
			cantvacios++;
			if(cantvacios == numdestinos)
			{
				MiSetFileAttributes(*elemento, atrib);
                CloseHandle(origen);
				free(bufferparadatos);
				return;
			}
			continue;
		}
        destinos[i] = CreateFileHechaPorMi(destinoparticular[i], GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE,
                        NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if(destinos[i] == INVALID_HANDLE_VALUE)
		{
			MiSetFileAttributes(*elemento, atrib);
            MiMostrarError(TEXT(__FILE__), __LINE__);
		}
    }
    while(1) 
    {
        resultado = ReadFile(origen, bufferparadatos, TAMANIOBUFFER, &bytleidos, NULL);
        if(resultado == 0)
		{
			MiSetFileAttributes(*elemento, atrib);
            MostrarError(TEXT(__FILE__), __LINE__);
		}

        if(bytleidos == 0)
        {
            GetFileTime(origen, &creac, &mod, &acc);
            for(i = 0; i < numdestinos; i++)
            {
				if(esvacio[i] == TRUE)
					continue;
                SetFileTime(destinos[i], &creac, &mod, &acc);
                CloseHandle(destinos[i]);
                MiSetFileAttributes(destinoparticular[i], atribvie);
            }
            CloseHandle(origen);
            acabado = TRUE;
            break;
        }
        for(i = 0; i < numdestinos; i++)
        {
			if(esvacio[i] == TRUE)
				continue;
            if(destinos[i] != INVALID_HANDLE_VALUE)
            {
                resultado = WriteFile(destinos[i], bufferparadatos, bytleidos, &bytescritos, NULL);
                if((resultado == 0) || (bytescritos != bytleidos))
				{
                    MiSetFileAttributes(*elemento, atrib);
					MostrarError(TEXT(__FILE__), __LINE__);
				}

            }
        }
        if(WaitForSingleObject(lpspd->evento, 0) == WAIT_OBJECT_0)
        {
            for(i = 0; i < numdestinos; i++)
            {
				if(esvacio[i] == TRUE)
					continue;
                CloseHandle(destinos[i]);
            }
            for(i = 0; i < numdestinos; i++)
            {
				if(wcslen(destinoparticular[i]) == 0)
					continue;
                DeleteFile(destinoparticular[i]);
            }
            CloseHandle(origen);
            free(bufferparadatos);
			MiSetFileAttributes(*elemento, atrib);
            return;
        }
    }
    free(bufferparadatos);
	MiSetFileAttributes(*elemento, atrib);
}
